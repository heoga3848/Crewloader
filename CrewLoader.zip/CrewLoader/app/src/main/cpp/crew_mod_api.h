// API para mods .crewag (nativos). Cada mod exporta crew_mod_init.
#pragma once
#include <jni.h>
#include <stdint.h>

#define CREW_API_VERSION 1

typedef struct CrewApi {
    uint32_t version;   // CREW_API_VERSION
    JavaVM*  vm;        // VM de Java del juego
    void (*log)(int priority, const char* tag, const char* message);  // android logcat
} CrewApi;

#ifdef __cplusplus
#define CREW_MOD_ENTRY extern "C" __attribute__((visibility("default"))) void crew_mod_init(const CrewApi* api)
#else
#define CREW_MOD_ENTRY __attribute__((visibility("default"))) void crew_mod_init(const CrewApi* api)
#endif
