cmake_minimum_required(VERSION 3.22.1)
project(crewloader CXX)
# Se compila como libmain.so: el parcheador lo coloca en el juego como proxy
# del libmain.so original (que pasa a llamarse libmain_orig.so).
add_library(main SHARED loader.cpp)
target_link_libraries(main log dl)
target_link_options(main PRIVATE -Wl,-z,max-page-size=16384)
