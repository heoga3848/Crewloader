cmake_minimum_required(VERSION 3.22.1)
project(crewloader CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
add_library(crewloader SHARED loader.cpp)
target_link_libraries(crewloader log dl z)
# Android 15: paginas de 16 KB
target_link_options(crewloader PRIVATE -Wl,-z,max-page-size=16384)
