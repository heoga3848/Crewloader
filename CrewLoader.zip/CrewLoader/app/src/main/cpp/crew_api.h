// CrewLoader mod API (v1). Copia este header en tu mod.
#pragma once
#include <jni.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CREW_API_VERSION 1

typedef struct CrewApi {
    uint32_t version;
    JavaVM* vm;
    void (*log)(int priority, const char* tag, const char* message);
} CrewApi;

// Cada mod DEBE exportar esta funcion (visibility default):
//   extern "C" __attribute__((visibility("default"))) void crew_mod_init(const CrewApi* api);
typedef void (*CrewModInitFn)(const CrewApi* api);

#ifdef __cplusplus
}
#endif
