// CrewLoader - loader nativo. Se carga ANTES de Unity (ver Bootstrap.java).
//  1) espera libil2cpp.so (dlopen RTLD_NOLOAD en loop) y il2cpp_domain_get() != NULL
//  2) lee config.json, extrae el .so de cada .crewag activado, dlopen + crew_mod_init(api)
//  3) crea el menu in-game (GameObject/Canvas/Button reales de Unity via il2cpp_runtime_invoke)
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>

#include <cstdint>
#include <cstring>
#include <fstream>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#define TAG "CrewLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

#if defined(__aarch64__)
#define ABI "arm64-v8a"
#elif defined(__arm__)
#define ABI "armeabi-v7a"
#else
#define ABI "unsupported"
#endif

// ---------------------------------------------------------------- API para mods
extern "C" {
typedef struct CrewApi {
    uint32_t version;
    JavaVM* vm;
    void (*log)(int priority, const char* tag, const char* message);
} CrewApi;
}

static JavaVM* g_vm = nullptr;
static CrewApi g_api;
static void apiLog(int prio, const char* tag, const char* msg) { __android_log_write(prio, tag, msg); }

// ---------------------------------------------------------------- estado
struct Mod {
    std::string id, name, version, author, path;
    bool enabled = false;      // segun config.json (lo que se guardara)
    bool loadedNow = false;    // cargado en esta sesion
    std::string status = "desactivado";
};
static std::vector<Mod> g_mods;
static std::string g_modsDir, g_cfgPath, g_cacheDir;
static bool g_started = false;

// ---------------------------------------------------------------- utilidades
static bool readFile(const std::string& p, std::string& out) {
    std::ifstream f(p, std::ios::binary);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    out = ss.str();
    return true;
}
static bool writeFile(const std::string& p, const std::string& data) {
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(data.data(), (std::streamsize)data.size());
    return (bool)f;
}
static void mkdirs(const std::string& path) {
    for (size_t i = 1; i <= path.size(); i++)
        if (i == path.size() || path[i] == '/') mkdir(path.substr(0, i).c_str(), 0755);
}
static std::string jstr(const std::string& j, const std::string& key) {
    size_t p = j.find("\"" + key + "\"");
    if (p == std::string::npos) return "";
    p = j.find(':', p);
    if (p == std::string::npos) return "";
    p = j.find('"', p);
    if (p == std::string::npos) return "";
    std::string r;
    for (size_t q = p + 1; q < j.size() && j[q] != '"'; q++) {
        if (j[q] == '\\' && q + 1 < j.size()) q++;
        r += j[q];
    }
    return r;
}
static std::set<std::string> jarr(const std::string& j, const std::string& key) {
    std::set<std::string> out;
    size_t p = j.find("\"" + key + "\"");
    if (p == std::string::npos) return out;
    size_t a = j.find('[', p), b = j.find(']', p);
    if (a == std::string::npos || b == std::string::npos) return out;
    for (size_t i = a; i < b;) {
        size_t s = j.find('"', i);
        if (s == std::string::npos || s > b) break;
        size_t e = j.find('"', s + 1);
        if (e == std::string::npos || e > b) break;
        out.insert(j.substr(s + 1, e - s - 1));
        i = e + 1;
    }
    return out;
}

// ---------------------------------------------------------------- lector ZIP minimo (zlib)
struct ZEnt { std::string name; uint16_t method; uint32_t csz, usz, lho; };
static uint16_t u16(const uint8_t* p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t u32(const uint8_t* p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24); }

static bool zipDir(const std::string& d, std::vector<ZEnt>& out, std::string& err) {
    auto* b = (const uint8_t*)d.data();
    size_t n = d.size();
    if (n < 22) { err = "zip invalido"; return false; }
    size_t e = n - 22;
    bool found = false;
    for (;;) {
        if (u32(b + e) == 0x06054b50) { found = true; break; }
        if (e == 0 || n - e > 70000) break;
        e--;
    }
    if (!found) { err = "no es un zip (EOCD)"; return false; }
    uint16_t cnt = u16(b + e + 10);
    size_t p = u32(b + e + 16);
    for (int i = 0; i < cnt; i++) {
        if (p + 46 > n || u32(b + p) != 0x02014b50) break;
        ZEnt z;
        z.method = u16(b + p + 10);
        z.csz = u32(b + p + 20);
        z.usz = u32(b + p + 24);
        uint16_t nl = u16(b + p + 28), el = u16(b + p + 30), cl = u16(b + p + 32);
        z.lho = u32(b + p + 42);
        z.name.assign((const char*)b + p + 46, nl);
        p += 46 + nl + el + cl;
        out.push_back(z);
    }
    return true;
}
static bool zipExtract(const std::string& d, const ZEnt& z, std::string& out, std::string& err) {
    auto* b = (const uint8_t*)d.data();
    size_t n = d.size();
    if ((size_t)z.lho + 30 > n) { err = "header local invalido"; return false; }
    size_t ds = z.lho + 30 + u16(b + z.lho + 26) + u16(b + z.lho + 28);
    if (ds + z.csz > n) { err = "datos fuera de rango"; return false; }
    if (z.method == 0) { out.assign((const char*)b + ds, z.csz); return true; }
    if (z.method != 8) { err = "compresion no soportada"; return false; }
    out.assign(z.usz, '\0');
    z_stream zs{};
    zs.next_in = (Bytef*)(b + ds);
    zs.avail_in = z.csz;
    zs.next_out = (Bytef*)&out[0];
    zs.avail_out = z.usz;
    if (inflateInit2(&zs, -MAX_WBITS) != Z_OK) { err = "inflateInit fallo"; return false; }
    int r = inflate(&zs, Z_FINISH);
    inflateEnd(&zs);
    if (r != Z_STREAM_END) { err = "inflate fallo"; return false; }
    return true;
}

// ---------------------------------------------------------------- config y mods
static void loadConfig(std::set<std::string>& en) {
    std::string j;
    if (readFile(g_cfgPath, j)) en = jarr(j, "enabled");
}
static void saveConfig() {
    std::string s = "{\"enabled\":[";
    bool first = true;
    for (auto& m : g_mods)
        if (m.enabled) {
            if (!first) s += ",";
            s += "\"" + m.id + "\"";
            first = false;
        }
    s += "]}";
    mkdirs(g_cfgPath.substr(0, g_cfgPath.rfind('/')));
    if (!writeFile(g_cfgPath, s)) LOGE("no se pudo guardar %s", g_cfgPath.c_str());
    else LOGI("config guardada: %s", s.c_str());
}
static void scanMods() {
    g_mods.clear();
    std::set<std::string> en;
    loadConfig(en);
    DIR* d = opendir(g_modsDir.c_str());
    if (!d) { LOGE("no se pudo abrir %s", g_modsDir.c_str()); return; }
    std::vector<std::string> files;
    while (dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n.size() > 7 && n.substr(n.size() - 7) == ".crewag") files.push_back(g_modsDir + "/" + n);
    }
    closedir(d);
    for (auto& f : files) {
        std::string zd, err, js;
        std::vector<ZEnt> ents;
        if (!readFile(f, zd) || !zipDir(zd, ents, err)) { LOGE("mod invalido %s: %s", f.c_str(), err.c_str()); continue; }
        bool ok = false;
        for (auto& z : ents)
            if (z.name == "mod.json") { ok = zipExtract(zd, z, js, err); break; }
        if (!ok) { LOGE("mod sin mod.json legible: %s", f.c_str()); continue; }
        Mod m;
        m.id = jstr(js, "id");
        m.name = jstr(js, "name");
        m.version = jstr(js, "version");
        m.author = jstr(js, "author");
        m.path = f;
        if (m.id.empty()) { LOGE("mod.json sin id: %s", f.c_str()); continue; }
        if (m.name.empty()) m.name = m.id;
        m.enabled = en.count(m.id) > 0;
        g_mods.push_back(m);
    }
}
static void loadMod(Mod& m) {
    std::string zd, err;
    std::vector<ZEnt> ents;
    if (!readFile(m.path, zd) || !zipDir(zd, ents, err)) { m.status = "error: " + err; LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }
    const std::string prefix = std::string("lib/") + ABI + "/";
    const ZEnt* lib = nullptr;
    for (auto& z : ents)
        if (z.name.compare(0, prefix.size(), prefix) == 0 && z.name.size() > 3 &&
            z.name.compare(z.name.size() - 3, 3, ".so") == 0) { lib = &z; break; }
    if (!lib) { m.status = std::string("error: sin lib para ") + ABI; LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }
    std::string data;
    if (!zipExtract(zd, *lib, data, err)) { m.status = "error: " + err; LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }

    std::string dir = g_cacheDir + "/crewmods/" + m.id;
    mkdirs(dir);
    std::string out = dir + "/" + lib->name.substr(prefix.size());
    unlink(out.c_str());
    if (!writeFile(out, data)) { m.status = "error: no se pudo extraer a " + out; LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }
    chmod(out.c_str(), 0444);

    void* h = dlopen(out.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!h) { m.status = std::string("error dlopen: ") + dlerror(); LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }
    auto init = (void (*)(const CrewApi*))dlsym(h, "crew_mod_init");
    if (!init) { m.status = "error: no exporta crew_mod_init"; LOGE("[%s] %s", m.id.c_str(), m.status.c_str()); return; }
    init(&g_api);
    m.loadedNow = true;
    m.status = "cargado";
    LOGI("[%s] v%s cargado OK", m.id.c_str(), m.version.c_str());
}

// ---------------------------------------------------------------- il2cpp
#define DECL(ret, name, args) typedef ret (*name##_t) args; static name##_t name = nullptr;
DECL(void*, il2cpp_domain_get, ())
DECL(void*, il2cpp_thread_attach, (void*))
DECL(void**, il2cpp_domain_get_assemblies, (void*, size_t*))
DECL(void*, il2cpp_assembly_get_image, (void*))
DECL(void*, il2cpp_class_from_name, (void*, const char*, const char*))
DECL(void*, il2cpp_class_get_method_from_name, (void*, const char*, int))
DECL(void*, il2cpp_class_get_parent, (void*))
DECL(void*, il2cpp_object_get_class, (void*))
DECL(void*, il2cpp_object_new, (void*))
DECL(void*, il2cpp_runtime_invoke, (void*, void*, void**, void**))
DECL(void*, il2cpp_string_new, (const char*))
DECL(void*, il2cpp_class_get_type, (void*))
DECL(void*, il2cpp_type_get_object, (void*))
DECL(uint32_t, il2cpp_gchandle_new, (void*, int))

static bool resolveIl2cpp(void* h) {
    bool ok = true;
#define RES(n) n = (n##_t)dlsym(h, #n); if (!n) { LOGE("simbolo il2cpp faltante: %s", #n); ok = false; }
    RES(il2cpp_domain_get) RES(il2cpp_thread_attach) RES(il2cpp_domain_get_assemblies)
    RES(il2cpp_assembly_get_image) RES(il2cpp_class_from_name) RES(il2cpp_class_get_method_from_name)
    RES(il2cpp_class_get_parent) RES(il2cpp_object_get_class) RES(il2cpp_object_new)
    RES(il2cpp_runtime_invoke) RES(il2cpp_string_new) RES(il2cpp_class_get_type)
    RES(il2cpp_type_get_object) RES(il2cpp_gchandle_new)
#undef RES
    return ok;
}

static void* g_dom = nullptr;
static std::map<std::string, void*> g_cc;

static void* findClass(const char* ns, const char* name) {
    std::string key = std::string(ns) + "." + name;
    auto it = g_cc.find(key);
    if (it != g_cc.end() && it->second) return it->second;
    size_t n = 0;
    void** as = il2cpp_domain_get_assemblies(g_dom, &n);
    for (size_t i = 0; i < n; i++) {
        void* img = il2cpp_assembly_get_image(as[i]);
        if (!img) continue;
        void* c = il2cpp_class_from_name(img, ns, name);
        if (c) { g_cc[key] = c; return c; }
    }
    return nullptr;
}
static void* findMethod(void* cls, const char* name, int argc) {
    for (void* c = cls; c; c = il2cpp_class_get_parent(c)) {
        void* m = il2cpp_class_get_method_from_name(c, name, argc);
        if (m) return m;
    }
    return nullptr;
}
// obj == nullptr -> metodo estatico de cls
static void* callM(void* cls, void* obj, const char* name, std::vector<void*> args) {
    if (obj) cls = il2cpp_object_get_class(obj);
    void* mi = cls ? findMethod(cls, name, (int)args.size()) : nullptr;
    if (!mi) { LOGE("metodo il2cpp no encontrado: %s/%zu", name, args.size()); return nullptr; }
    void* exc = nullptr;
    void* r = il2cpp_runtime_invoke(mi, obj, args.data(), &exc);
    if (exc) { LOGE("excepcion managed en %s", name); return nullptr; }
    return r;
}
static void* callO(void* obj, const char* name, std::vector<void*> args = {}) { return callM(nullptr, obj, name, std::move(args)); }
static void* callS(void* cls, const char* name, std::vector<void*> args = {}) { return callM(cls, nullptr, name, std::move(args)); }
static void* S(const char* s) { return il2cpp_string_new(s); }
static void* typeOf(void* cls) { return il2cpp_type_get_object(il2cpp_class_get_type(cls)); }
static void pin(void* o) { il2cpp_gchandle_new(o, 0); }

// Delegates "falsos" cuyo method_ptr es una funcion nativa (se invocan como metodo de instancia: fn(target, MethodInfo*))
static void* makeDelegate(void* delegateCls, void* target, void* fn) {
    void* d = il2cpp_object_new(delegateCls);
    void* invoke = il2cpp_class_get_method_from_name(delegateCls, "Invoke", 0);
    void** p = (void**)d;  // [0]=klass [1]=monitor [2]=method_ptr [3]=invoke_impl [4]=target [5]=method
    p[2] = fn;
    p[3] = fn;
    p[4] = target;
    p[5] = invoke;
    pin(d);
    return d;
}

static std::map<void*, std::function<void()>> g_clicks;
static void clickThunk(void* self, const void*) {
    auto it = g_clicks.find(self);
    if (it != g_clicks.end()) it->second();
}
static bool g_uiBuilt = false;
static void buildUI();
static void tickThunk(void*, const void*) {
    if (g_uiBuilt) return;
    g_uiBuilt = true;
    buildUI();
}

// ---------------------------------------------------------------- helpers de UI Unity
struct V2 { float x, y; };
struct Col { float r, g, b, a; };
static void *C_GO, *C_Canvas, *C_Scaler, *C_Raycaster, *C_Image, *C_Button, *C_Text, *C_TMP, *C_UnityAction;
static void* g_font = nullptr;

static void* newGO(const char* name) {
    void* go = il2cpp_object_new(C_GO);
    void* m = findMethod(C_GO, ".ctor", 1);
    void* a[1] = {S(name)};
    void* exc = nullptr;
    il2cpp_runtime_invoke(m, go, a, &exc);
    if (exc) LOGE("excepcion creando GameObject %s", name);
    return go;
}
static void* addComp(void* go, void* cls) { return callO(go, "AddComponent", {typeOf(cls)}); }
static void setActive(void* go, bool b) { callO(go, "SetActive", {&b}); }
static void dontDestroy(void* go) { callS(findClass("UnityEngine", "Object"), "DontDestroyOnLoad", {go}); }
static void setColor(void* graphic, Col c) { callO(graphic, "set_color", {&c}); }
static void rect(void* tr, float ax0, float ay0, float ax1, float ay1, float ox0, float oy0, float ox1, float oy1) {
    V2 a0{ax0, ay0}, a1{ax1, ay1}, o0{ox0, oy0}, o1{ox1, oy1};
    callO(tr, "set_anchorMin", {&a0});
    callO(tr, "set_anchorMax", {&a1});
    callO(tr, "set_offsetMin", {&o0});
    callO(tr, "set_offsetMax", {&o1});
}
static void attach(void* go, void* parentTr, float ax0, float ay0, float ax1, float ay1, float ox0, float oy0, float ox1, float oy1) {
    void* tr = callO(go, "get_transform");
    bool keep = false;
    callO(tr, "SetParent", {parentTr, &keep});
    rect(tr, ax0, ay0, ax1, ay1, ox0, oy0, ox1, oy1);
}
static void* getFont() {
    if (g_font) return g_font;
    void* fc = findClass("UnityEngine", "Font");
    void* rc = findClass("UnityEngine", "Resources");
    if (!fc || !rc) return nullptr;
    for (const char* n : {"LegacyRuntime.ttf", "Arial.ttf"}) {
        void* f = callS(rc, "GetBuiltinResource", {typeOf(fc), S(n)});
        if (f) { g_font = f; pin(f); return f; }
    }
    return nullptr;
}

struct Label { void* comp = nullptr; bool tmp = false; };
static void setText(Label& l, const char* t) { if (l.comp) callO(l.comp, "set_text", {S(t)}); }
static Label newLabel(void* parentTr, const char* text, float fs, Col col,
                      float ax0, float ay0, float ax1, float ay1, float ox0, float oy0, float ox1, float oy1) {
    Label L;
    void* go = newGO("Label");
    if (C_Text && getFont()) {
        L.comp = addComp(go, C_Text);
        callO(L.comp, "set_font", {g_font});
        int sz = (int)fs, al = 4;  // TextAnchor.MiddleCenter
        callO(L.comp, "set_fontSize", {&sz});
        callO(L.comp, "set_alignment", {&al});
    } else if (C_TMP) {
        L.tmp = true;
        L.comp = addComp(go, C_TMP);
        float f = fs;
        int al = 514;  // TextAlignmentOptions.Center
        callO(L.comp, "set_fontSize", {&f});
        callO(L.comp, "set_alignment", {&al});
    } else {
        LOGE("no hay Text ni TextMeshProUGUI disponible");
        return L;
    }
    setColor(L.comp, col);
    setText(L, text);
    attach(go, parentTr, ax0, ay0, ax1, ay1, ox0, oy0, ox1, oy1);
    return L;
}
static void* newPanel(void* parentTr, const char* name, Col c, float ax0, float ay0, float ax1, float ay1,
                      float ox0, float oy0, float ox1, float oy1, void** goOut = nullptr) {
    void* go = newGO(name);
    void* img = addComp(go, C_Image);
    setColor(img, c);
    attach(go, parentTr, ax0, ay0, ax1, ay1, ox0, oy0, ox1, oy1);
    if (goOut) *goOut = go;
    return callO(go, "get_transform");
}
struct Btn { void* go = nullptr; void* img = nullptr; Label lbl; };
static Btn newButton(void* parentTr, const char* text, Col bg, float ax0, float ay0, float ax1, float ay1,
                     float ox0, float oy0, float ox1, float oy1, std::function<void()> fn) {
    Btn b;
    b.go = newGO("Btn");
    b.img = addComp(b.go, C_Image);
    setColor(b.img, bg);
    void* btn = addComp(b.go, C_Button);
    callO(btn, "set_targetGraphic", {b.img});
    attach(b.go, parentTr, ax0, ay0, ax1, ay1, ox0, oy0, ox1, oy1);
    b.lbl = newLabel(callO(b.go, "get_transform"), text, 22, Col{1, 1, 1, 1}, 0, 0, 1, 1, 0, 0, 0, 0);
    void* tgt = il2cpp_object_new(findClass("System", "Object"));
    pin(tgt);
    g_clicks[tgt] = std::move(fn);
    void* d = makeDelegate(C_UnityAction, tgt, (void*)&clickThunk);
    void* ev = callO(btn, "get_onClick");
    callO(ev, "AddListener", {d});
    return b;
}

static std::string modLine(const Mod& m) {
    std::string s = m.name + "  v" + m.version + "  -  " + m.author + "\n";
    if (m.loadedNow && m.enabled) s += "cargado";
    else if (m.loadedNow && !m.enabled) s += "cargado (se desactiva al reiniciar)";
    else if (m.enabled) s += (m.status == "desactivado") ? "se activara al reiniciar" : m.status;
    else s += (m.status.rfind("error", 0) == 0) ? m.status : "desactivado";
    return s;
}

// ---------------------------------------------------------------- menu in-game
static void buildUI() {
    LOGI("construyendo menu in-game...");
    C_GO = findClass("UnityEngine", "GameObject");
    C_Canvas = findClass("UnityEngine", "Canvas");
    C_Scaler = findClass("UnityEngine.UI", "CanvasScaler");
    C_Raycaster = findClass("UnityEngine.UI", "GraphicRaycaster");
    C_Image = findClass("UnityEngine.UI", "Image");
    C_Button = findClass("UnityEngine.UI", "Button");
    C_Text = findClass("UnityEngine.UI", "Text");
    C_TMP = findClass("TMPro", "TextMeshProUGUI");
    C_UnityAction = findClass("UnityEngine.Events", "UnityAction");
    const struct { const char* n; void* c; } need[] = {
        {"GameObject", C_GO}, {"Canvas", C_Canvas}, {"CanvasScaler", C_Scaler}, {"GraphicRaycaster", C_Raycaster},
        {"Image", C_Image}, {"Button", C_Button}, {"UnityAction", C_UnityAction}};
    bool ok = true;
    for (auto& x : need) if (!x.c) { LOGE("clase Unity no disponible en este build (strip?): %s", x.n); ok = false; }
    if (!ok) return;

    // EventSystem (si el juego no tiene uno)
    void* esCls = findClass("UnityEngine.EventSystems", "EventSystem");
    if (esCls && !callS(esCls, "get_current")) {
        void* go = newGO("CrewLoaderEventSystem");
        addComp(go, esCls);
        void* sim = findClass("UnityEngine.EventSystems", "StandaloneInputModule");
        if (sim) addComp(go, sim);
        dontDestroy(go);
    }

    void* root = newGO("CrewLoaderCanvas");
    void* canvas = addComp(root, C_Canvas);
    int rm = 0, so = 32000;  // ScreenSpaceOverlay
    callO(canvas, "set_renderMode", {&rm});
    callO(canvas, "set_sortingOrder", {&so});
    void* sc = addComp(root, C_Scaler);
    int mode = 1;
    V2 ref{1280, 720};
    float mw = 0.5f;
    callO(sc, "set_uiScaleMode", {&mode});
    callO(sc, "set_referenceResolution", {&ref});
    callO(sc, "set_matchWidthOrHeight", {&mw});
    addComp(root, C_Raycaster);
    dontDestroy(root);
    void* rtr = callO(root, "get_transform");

    // Panel (oculto al inicio)
    void* panelGo = nullptr;
    void* ptr = newPanel(rtr, "CrewPanel", Col{0, 0, 0, 0.85f}, 0.2f, 0.08f, 0.8f, 0.92f, 0, 0, 0, 0, &panelGo);
    newLabel(ptr, "CrewLoader - Mods", 30, Col{1, 1, 1, 1}, 0, 1, 1, 1, 0, -60, 0, -8);
    Label* note = new Label(newLabel(ptr, "", 20, Col{1, 0.85f, 0.3f, 1}, 0, 0, 1, 0, 10, 70, -10, 110));

    const int MAX_ROWS = 7;
    std::vector<Label*> rowLabels;
    for (size_t i = 0; i < g_mods.size() && (int)i < MAX_ROWS; i++) {
        float top = -(70.f + i * 58.f);
        void* row = newPanel(ptr, "Row", Col{0.13f, 0.13f, 0.16f, 0.95f}, 0, 1, 1, 1, 16, top - 52, -16, top);
        auto* lab = new Label(newLabel(row, modLine(g_mods[i]).c_str(), 18, Col{1, 1, 1, 1}, 0, 0, 0.74f, 1, 10, 0, 0, 0));
        rowLabels.push_back(lab);
        Btn* tb = new Btn();
        size_t idx = i;
        *tb = newButton(row, g_mods[i].enabled ? "ON" : "OFF",
                        g_mods[i].enabled ? Col{0.2f, 0.7f, 0.3f, 1} : Col{0.45f, 0.45f, 0.5f, 1},
                        0.78f, 0.12f, 0.98f, 0.88f, 0, 0, 0, 0, [idx, tb, lab, note]() {
                            Mod& m = g_mods[idx];
                            m.enabled = !m.enabled;
                            saveConfig();
                            setText(tb->lbl, m.enabled ? "ON" : "OFF");
                            setColor(tb->img, m.enabled ? Col{0.2f, 0.7f, 0.3f, 1} : Col{0.45f, 0.45f, 0.5f, 1});
                            setText(*lab, modLine(m).c_str());
                            setText(*note, "Reinicia el juego para aplicar los cambios");
                        });
    }
    if (g_mods.empty()) newLabel(ptr, "No hay mods en /CrewLoader/mods", 22, Col{0.8f, 0.8f, 0.8f, 1}, 0, 0.4f, 1, 0.6f, 0, 0, 0, 0);
    if ((int)g_mods.size() > MAX_ROWS) newLabel(ptr, "(hay mas mods: administralos desde la app)", 16, Col{0.7f, 0.7f, 0.7f, 1}, 0, 0, 1, 0, 0, 118, 0, 140);

    newButton(ptr, "Cerrar", Col{0.12f, 0.45f, 0.9f, 1}, 0.3f, 0, 0.7f, 0, 0, 10, 0, 62,
              [panelGo]() { setActive(panelGo, false); });
    setActive(panelGo, false);

    // Boton flotante
    newButton(rtr, "MODS", Col{0.12f, 0.45f, 0.9f, 0.95f}, 0, 0.5f, 0, 0.5f, 10, -32, 110, 32,
              [panelGo]() { setActive(panelGo, true); });
    LOGI("menu in-game listo");
}

// ---------------------------------------------------------------- hilo principal del loader
static void worker() {
    LOGI("esperando libil2cpp.so...");
    void* h = nullptr;
    for (int i = 0; i < 1800 && !h; i++) {  // ~3 min
        h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!h) usleep(100 * 1000);
    }
    if (!h) { LOGE("libil2cpp.so nunca se cargo; abortando"); return; }
    LOGI("libil2cpp.so cargado");
    if (!resolveIl2cpp(h)) return;

    for (int i = 0; i < 1800; i++) {
        g_dom = il2cpp_domain_get();
        if (g_dom) break;
        usleep(100 * 1000);
    }
    if (!g_dom) { LOGE("il2cpp_domain_get() nunca devolvio un dominio"); return; }
    il2cpp_thread_attach(g_dom);
    LOGI("dominio il2cpp valido: %p", g_dom);

    // esperar a que Unity registre sus assemblies
    for (int i = 0; i < 600; i++) {
        size_t n = 0;
        il2cpp_domain_get_assemblies(g_dom, &n);
        if (n > 8 && findClass("UnityEngine", "GameObject")) break;
        usleep(100 * 1000);
    }

    scanMods();
    LOGI("%zu mod(s) encontrados en %s", g_mods.size(), g_modsDir.c_str());
    for (auto& m : g_mods) {
        if (!m.enabled) { LOGI("[%s] desactivado, se omite", m.id.c_str()); continue; }
        loadMod(m);
    }

    // hook al main thread de Unity: Application.onBeforeRender
    void* app = findClass("UnityEngine", "Application");
    void* ua = findClass("UnityEngine.Events", "UnityAction");
    if (!app || !ua) { LOGE("no se pudo preparar el menu (Application/UnityAction)"); return; }
    void* tgt = il2cpp_object_new(findClass("System", "Object"));
    pin(tgt);
    void* d = makeDelegate(ua, tgt, (void*)&tickThunk);
    callS(app, "add_onBeforeRender", {d});
    LOGI("hook de main-thread registrado; el menu se crea en el siguiente frame");
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    g_api.version = 1;
    g_api.vm = vm;
    g_api.log = apiLog;
    LOGI("libcrewloader.so cargado (ABI %s)", ABI);
    return JNI_VERSION_1_6;
}

static std::string toStd(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" JNIEXPORT void JNICALL Java_com_crewloader_Bootstrap_nativeInit(JNIEnv* env, jclass, jstring mods, jstring cfg, jstring cache) {
    if (g_started) return;
    g_started = true;
    g_modsDir = toStd(env, mods);
    g_cfgPath = toStd(env, cfg);
    g_cacheDir = toStd(env, cache);
    std::thread(worker).detach();
}
