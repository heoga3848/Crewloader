// CrewLoader: proxy de libmain.so.
// 1) Carga el libmain original (libmain_orig.so) y le reenvía JNI_OnLoad.
// 2) Carga los mods incluidos en el APK (libcrewmod0.so, libcrewmod1.so, ...)
//    y llama a crew_mod_init(api) en cada uno.
#include <android/log.h>
#include <dlfcn.h>
#include <jni.h>
#include <stdio.h>
#include <string>
#include "crew_mod_api.h"

#define TAG "CrewLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

typedef jint (*OnLoadFn)(JavaVM*, void*);
typedef void (*ModInitFn)(const CrewApi*);

static void api_log(int priority, const char* tag, const char* msg) {
    __android_log_print(priority, tag, "%s", msg);
}

static std::string self_dir() {
    Dl_info info;
    if (dladdr((void*)&api_log, &info) && info.dli_fname) {
        std::string p = info.dli_fname;
        size_t i = p.rfind('/');
        if (i != std::string::npos) return p.substr(0, i);
    }
    return "";
}

static void load_mods(JavaVM* vm) {
    static CrewApi api;
    api.version = CREW_API_VERSION;
    api.vm = vm;
    api.log = api_log;
    std::string dir = self_dir();
    int loaded = 0;
    for (int i = 0; i < 64; i++) {
        char name[64];
        snprintf(name, sizeof(name), "libcrewmod%d.so", i);
        void* h = dlopen(name, RTLD_NOW);
        if (!h && !dir.empty()) h = dlopen((dir + "/" + name).c_str(), RTLD_NOW);
        if (!h) continue;  // este ABI no trae ese mod
        auto init = (ModInitFn)dlsym(h, "crew_mod_init");
        if (!init) { LOGE("%s no exporta crew_mod_init", name); continue; }
        init(&api);
        loaded++;
        LOGI("mod cargado: %s", name);
    }
    LOGI("%d mod(s) cargados", loaded);
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    jint version = JNI_VERSION_1_6;
    std::string dir = self_dir();
    void* orig = nullptr;
    if (!dir.empty()) orig = dlopen((dir + "/libmain_orig.so").c_str(), RTLD_NOW);
    if (!orig) orig = dlopen("libmain_orig.so", RTLD_NOW);
    if (orig) {
        auto fn = (OnLoadFn)dlsym(orig, "JNI_OnLoad");
        if (fn) version = fn(vm, reserved);
    } else {
        LOGE("no pude cargar libmain_orig.so: %s", dlerror());
    }
    load_mods(vm);
    return version;
}
