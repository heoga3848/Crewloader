// CrewLoader - loader nativo para Among Us (Unity IL2CPP, Android).
// Escrito desde cero. Flujo:
//   JNI_OnLoad -> hilo -> espera libil2cpp.so -> espera il2cpp_domain_get() != null
//   -> lee mods.json -> dlopen + crew_mod_init de cada mod activado
//   -> se suscribe a Application.onBeforeRender (hilo principal de Unity) y construye el menu.
#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <unistd.h>

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <functional>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include "crew_api.h"

#define TAG "CrewLoader"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static void sleepMs(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

// ===================================================================== estado global
struct Mod {
    std::string id, name, version, author, lib;
    bool enabled = false;
    bool loaded = false;
};

static JavaVM* g_vm = nullptr;
static jclass g_bootCls = nullptr;
static jmethodID g_menuFailed = nullptr;
static std::string g_home;
static std::vector<Mod> g_mods;
static CrewApi g_api;

static void apiLog(int prio, const char* tag, const char* msg) {
    __android_log_write(prio, tag ? tag : "CrewMod", msg ? msg : "");
}

// ===================================================================== JSON minimo
static std::string readFile(const std::string& p) {
    std::ifstream f(p, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static bool writeFile(const std::string& p, const std::string& s) {
    std::string tmp = p + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f << s;
    }
    return rename(tmp.c_str(), p.c_str()) == 0;
}

static std::string esc(const std::string& s) {
    std::string o;
    for (char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\t': o += "\\t"; break;
            default:
                if ((unsigned char)c >= 0x20) o += c;
        }
    }
    return o;
}

static std::string jstr(const std::string& o, const std::string& key) {
    std::string k = "\"" + key + "\"";
    size_t p = o.find(k);
    if (p == std::string::npos) return "";
    p = o.find(':', p + k.size());
    if (p == std::string::npos) return "";
    p = o.find('"', p);
    if (p == std::string::npos) return "";
    std::string r;
    for (size_t i = p + 1; i < o.size(); ++i) {
        char c = o[i];
        if (c == '"') break;
        if (c == '\\' && i + 1 < o.size()) {
            char n = o[++i];
            r += (n == 'n') ? '\n' : (n == 't') ? '\t' : n;  // incluye "\/" -> "/"
        } else {
            r += c;
        }
    }
    return r;
}

static bool jbool(const std::string& o, const std::string& key, bool def) {
    std::string k = "\"" + key + "\"";
    size_t p = o.find(k);
    if (p == std::string::npos) return def;
    p = o.find(':', p + k.size());
    if (p == std::string::npos) return def;
    ++p;
    while (p < o.size() && (o[p] == ' ' || o[p] == '\n' || o[p] == '\t')) ++p;
    if (o.compare(p, 4, "true") == 0) return true;
    if (o.compare(p, 5, "false") == 0) return false;
    return def;
}

// Devuelve cada objeto {...} (planos) del primer arreglo [...] del texto.
static std::vector<std::string> splitObjects(const std::string& s) {
    std::vector<std::string> out;
    size_t arr = s.find('[');
    if (arr == std::string::npos) return out;
    bool inStr = false;
    int depth = 0;
    size_t start = 0;
    for (size_t i = arr + 1; i < s.size(); ++i) {
        char c = s[i];
        if (inStr) {
            if (c == '\\') ++i;
            else if (c == '"') inStr = false;
            continue;
        }
        if (c == '"') { inStr = true; continue; }
        if (c == '{') { if (depth++ == 0) start = i; }
        else if (c == '}') { if (--depth == 0) out.push_back(s.substr(start, i - start + 1)); }
        else if (c == ']' && depth == 0) break;
    }
    return out;
}

static std::string manifestPath() { return g_home + "/mods.json"; }

static void readManifest() {
    g_mods.clear();
    for (auto& o : splitObjects(readFile(manifestPath()))) {
        Mod m;
        m.id = jstr(o, "id");
        m.name = jstr(o, "name");
        m.version = jstr(o, "version");
        m.author = jstr(o, "author");
        m.lib = jstr(o, "lib");
        m.enabled = jbool(o, "enabled", false);
        if (!m.id.empty()) g_mods.push_back(m);
    }
    LOGI("mods.json: %zu mods", g_mods.size());
}

static void saveManifest() {
    std::string s = "{\"mods\":[";
    for (size_t i = 0; i < g_mods.size(); ++i) {
        const Mod& m = g_mods[i];
        if (i) s += ",";
        s += "{\"id\":\"" + esc(m.id) + "\",\"name\":\"" + esc(m.name) + "\",\"version\":\"" +
             esc(m.version) + "\",\"author\":\"" + esc(m.author) + "\",\"lib\":\"" + esc(m.lib) +
             "\",\"enabled\":" + (m.enabled ? "true" : "false") + "}";
    }
    s += "]}";
    if (!writeFile(manifestPath(), s)) LOGE("no pude escribir %s", manifestPath().c_str());
}

// ===================================================================== carga de mods
static bool loadMod(Mod& m) {
    if (m.loaded || m.lib.empty()) return false;
    void* h = dlopen(m.lib.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!h) { LOGE("dlopen(%s) fallo: %s", m.id.c_str(), dlerror()); return false; }
    auto init = reinterpret_cast<CrewModInitFn>(dlsym(h, "crew_mod_init"));
    if (!init) { LOGE("%s no exporta crew_mod_init", m.id.c_str()); dlclose(h); return false; }
    init(&g_api);
    m.loaded = true;
    LOGI("mod cargado: %s v%s", m.id.c_str(), m.version.c_str());
    return true;
}

// ===================================================================== API de IL2CPP
static void* (*p_domain_get)();
static void* (*p_thread_attach)(void*);
static void** (*p_domain_get_assemblies)(void*, size_t*);
static void* (*p_assembly_get_image)(void*);
static void* (*p_class_from_name)(void*, const char*, const char*);
static void* (*p_class_get_method_from_name)(void*, const char*, int);
static void* (*p_class_get_type)(void*);
static void* (*p_type_get_object)(void*);
static void* (*p_object_new)(void*);
static void* (*p_runtime_invoke)(void*, void*, void**, void**);
static void* (*p_string_new)(const char*);
static uint32_t (*p_gchandle_new)(void*, int);

static bool resolveApi(void* h) {
    bool ok = true;
#define RES(var, sym) do { *(void**)&var = dlsym(h, sym); if (!var) { LOGE("falta %s", sym); ok = false; } } while (0)
    RES(p_domain_get, "il2cpp_domain_get");
    RES(p_thread_attach, "il2cpp_thread_attach");
    RES(p_domain_get_assemblies, "il2cpp_domain_get_assemblies");
    RES(p_assembly_get_image, "il2cpp_assembly_get_image");
    RES(p_class_from_name, "il2cpp_class_from_name");
    RES(p_class_get_method_from_name, "il2cpp_class_get_method_from_name");
    RES(p_class_get_type, "il2cpp_class_get_type");
    RES(p_type_get_object, "il2cpp_type_get_object");
    RES(p_object_new, "il2cpp_object_new");
    RES(p_runtime_invoke, "il2cpp_runtime_invoke");
    RES(p_string_new, "il2cpp_string_new");
    RES(p_gchandle_new, "il2cpp_gchandle_new");
#undef RES
    return ok;
}

// ===================================================================== helpers IL2CPP
static void* g_domain = nullptr;
static bool g_fail = false;

static void* findClass(const char* ns, const char* name) {
    size_t n = 0;
    void** as = p_domain_get_assemblies(g_domain, &n);
    for (size_t i = 0; i < n; ++i) {
        void* img = p_assembly_get_image(as[i]);
        if (!img) continue;
        void* k = p_class_from_name(img, ns, name);
        if (k) return k;
    }
    LOGW("clase no encontrada: %s.%s", ns, name);
    return nullptr;
}

static void* meth(void* k, const char* name, int argc) {
    void* m = k ? p_class_get_method_from_name(k, name, argc) : nullptr;
    if (!m) { LOGE("metodo no encontrado: %s/%d", name, argc); g_fail = true; }
    return m;
}

static void* call(void* m, void* self, void** args = nullptr) {
    if (!m) { g_fail = true; return nullptr; }
    void* exc = nullptr;
    void* r = p_runtime_invoke(m, self, args, &exc);
    if (exc) { LOGE("excepcion administrada en invoke"); g_fail = true; return nullptr; }
    return r;
}

static void* typeObj(void* k) { return p_type_get_object(p_class_get_type(k)); }
static void* mstr(const char* s) { return p_string_new(s); }

struct V2 { float x, y; };
struct Col { float r, g, b, a; };

struct Cls {
    void *Application, *GameObject, *Transform, *RectTransform, *Canvas, *Scaler, *Raycaster,
         *Graphic, *Image, *Button, *Text, *Font, *Resources, *UnityEvent, *UnityAction, *Object,
         *EventSystem, *StdInput;
} C;

// ---- Delegates fabricados: un UnityAction administrado que apunta a una funcion nativa.
struct DelegateRaw {            // prefijo del layout de Il2CppDelegate
    void* klass;
    void* monitor;
    void* method_ptr;
    void* invoke_impl;
    void* target;
    void* method;
};

static void* g_dummyMethod = nullptr;  // MethodInfo instancia sin parametros (GameObject.get_activeSelf)
static std::unordered_map<void*, std::function<void()>> g_actions;

static void thunk(void* target, void* /*method*/) {
    auto it = g_actions.find(target);
    if (it != g_actions.end()) it->second();
}

static void* makeAction(std::function<void()> fn) {
    void* d = p_object_new(C.UnityAction);
    if (!d) { g_fail = true; return nullptr; }
    auto* r = reinterpret_cast<DelegateRaw*>(d);
    r->method_ptr = reinterpret_cast<void*>(&thunk);
    r->invoke_impl = reinterpret_cast<void*>(&thunk);
    r->target = d;
    r->method = g_dummyMethod;
    p_gchandle_new(d, 1);
    g_actions[d] = std::move(fn);
    return d;
}

// ---- reporte de fallo al lado Java (muestra el menu Android de respaldo)
static void reportMenuFailed() {
    if (!g_vm || !g_bootCls || !g_menuFailed) return;
    JNIEnv* env = nullptr;
    bool attached = false;
    if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;
        attached = true;
    }
    env->CallStaticVoidMethod(g_bootCls, g_menuFailed);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) g_vm->DetachCurrentThread();
}

// ===================================================================== construccion de UI
struct El { void* go; void* rt; };
struct Btn { El el; void* img; void* text; };
struct Row { void* img; void* text; };

static void* g_font = nullptr;
static void* g_panel = nullptr;       // GameObject del panel
static bool g_panelOpen = false;
static std::vector<Row> g_rows;

static void setV2(const char* setter, void* obj, float x, float y) {
    V2 v{x, y};
    void* a[] = {&v};
    call(meth(C.RectTransform, setter, 1), obj, a);
}

static void setColor(void* graphic, float r, float g, float b, float a) {
    Col c{r, g, b, a};
    void* args[] = {&c};
    call(meth(C.Graphic, "set_color", 1), graphic, args);
}

static void setActive(void* go, bool on) {
    void* a[] = {&on};
    call(meth(C.GameObject, "SetActive", 1), go, a);
}

static void* newGO(const char* name) {
    void* go = p_object_new(C.GameObject);
    void* a[] = {mstr(name)};
    call(meth(C.GameObject, ".ctor", 1), go, a);
    return go;
}

static void* comp(void* go, void* klass) {
    void* a[] = {typeObj(klass)};
    return call(meth(C.GameObject, "AddComponent", 1), go, a);
}

static void keepAlive(void* go) {
    void* a[] = {go};
    call(meth(C.Object, "DontDestroyOnLoad", 1), nullptr, a);
}

static El mk(void* parentRT, const char* name, V2 amin, V2 amax, V2 pivot, V2 pos, V2 size) {
    El e;
    e.go = newGO(name);
    e.rt = comp(e.go, C.RectTransform);
    if (parentRT) {
        bool keep = false;
        void* a[] = {parentRT, &keep};
        call(meth(C.Transform, "SetParent", 2), e.rt, a);
    }
    setV2("set_anchorMin", e.rt, amin.x, amin.y);
    setV2("set_anchorMax", e.rt, amax.x, amax.y);
    setV2("set_pivot", e.rt, pivot.x, pivot.y);
    setV2("set_anchoredPosition", e.rt, pos.x, pos.y);
    setV2("set_sizeDelta", e.rt, size.x, size.y);
    return e;
}

static void* addImage(El& e, Col c) {
    void* img = comp(e.go, C.Image);
    setColor(img, c.r, c.g, c.b, c.a);
    return img;
}

static void* addText(El& e, const char* txt, int size, int align) {
    void* t = comp(e.go, C.Text);
    void* a1[] = {mstr(txt)};
    call(meth(C.Text, "set_text", 1), t, a1);
    void* a2[] = {g_font};
    call(meth(C.Text, "set_font", 1), t, a2);
    void* a3[] = {&size};
    call(meth(C.Text, "set_fontSize", 1), t, a3);
    void* a4[] = {&align};
    call(meth(C.Text, "set_alignment", 1), t, a4);
    setColor(t, 1.f, 1.f, 1.f, 1.f);
    return t;
}

static void setText(void* text, const char* s) {
    void* a[] = {mstr(s)};
    call(meth(C.Text, "set_text", 1), text, a);
}

static Btn mkButton(void* parentRT, const char* name, const char* label, V2 amin, V2 amax,
                    V2 pivot, V2 pos, V2 size, Col color, std::function<void()> onClick) {
    Btn b;
    b.el = mk(parentRT, name, amin, amax, pivot, pos, size);
    b.img = addImage(b.el, color);
    void* button = comp(b.el.go, C.Button);
    El t = mk(b.el.rt, "Label", {0, 0}, {1, 1}, {0.5f, 0.5f}, {0, 0}, {0, 0});
    b.text = addText(t, label, 26, 4);
    void* ev = call(meth(C.Button, "get_onClick", 0), button);
    void* act = makeAction(std::move(onClick));
    void* a[] = {act};
    call(meth(C.UnityEvent, "AddListener", 1), ev, a);
    return b;
}

static const Col kBlue{0.10f, 0.45f, 0.95f, 1.f};
static const Col kGray{0.35f, 0.35f, 0.35f, 1.f};

static void refreshRow(size_t i) {
    const Mod& m = g_mods[i];
    Col c = m.enabled ? kBlue : kGray;
    setColor(g_rows[i].img, c.r, c.g, c.b, c.a);
    setText(g_rows[i].text, m.enabled ? "ON" : "OFF");
}

static void onToggle(size_t i) {
    Mod& m = g_mods[i];
    m.enabled = !m.enabled;
    saveManifest();
    if (m.enabled && !m.loaded) loadMod(m);
    refreshRow(i);
}

static bool prepareClasses() {
    C.Application = findClass("UnityEngine", "Application");
    C.GameObject = findClass("UnityEngine", "GameObject");
    C.UnityAction = findClass("UnityEngine.Events", "UnityAction");
    if (!C.Application || !C.GameObject || !C.UnityAction) return false;
    g_dummyMethod = p_class_get_method_from_name(C.GameObject, "get_activeSelf", 0);
    return g_dummyMethod != nullptr;
}

static bool prepareUiClasses() {
    C.Transform = findClass("UnityEngine", "Transform");
    C.RectTransform = findClass("UnityEngine", "RectTransform");
    C.Canvas = findClass("UnityEngine", "Canvas");
    C.Font = findClass("UnityEngine", "Font");
    C.Resources = findClass("UnityEngine", "Resources");
    C.Object = findClass("UnityEngine", "Object");
    C.UnityEvent = findClass("UnityEngine.Events", "UnityEvent");
    C.Scaler = findClass("UnityEngine.UI", "CanvasScaler");
    C.Raycaster = findClass("UnityEngine.UI", "GraphicRaycaster");
    C.Graphic = findClass("UnityEngine.UI", "Graphic");
    C.Image = findClass("UnityEngine.UI", "Image");
    C.Button = findClass("UnityEngine.UI", "Button");
    C.Text = findClass("UnityEngine.UI", "Text");
    C.EventSystem = findClass("UnityEngine.EventSystems", "EventSystem");
    C.StdInput = findClass("UnityEngine.EventSystems", "StandaloneInputModule");
    return C.Transform && C.RectTransform && C.Canvas && C.Font && C.Resources && C.Object &&
           C.UnityEvent && C.Scaler && C.Raycaster && C.Graphic && C.Image && C.Button &&
           C.Text && C.EventSystem && C.StdInput;
}

static bool loadFont() {
    const char* names[] = {"LegacyRuntime.ttf", "Arial.ttf"};
    for (const char* n : names) {
        void* a[] = {typeObj(C.Font), mstr(n)};
        void* exc = nullptr;
        void* m = p_class_get_method_from_name(C.Resources, "GetBuiltinResource", 2);
        if (!m) break;
        void* f = p_runtime_invoke(m, nullptr, a, &exc);
        if (!exc && f) { g_font = f; p_gchandle_new(f, 1); return true; }
    }
    LOGE("no encontre fuente integrada");
    return false;
}

// Corre UNA vez en el hilo principal de Unity.
static bool buildUI() {
    g_fail = false;
    if (!prepareUiClasses() || !loadFont()) return false;

    // Canvas raiz (overlay, siempre encima, sobrevive cambios de escena)
    void* rootGO = newGO("CrewLoaderCanvas");
    void* canvas = comp(rootGO, C.Canvas);
    int renderMode = 0;  // ScreenSpaceOverlay
    void* a1[] = {&renderMode};
    call(meth(C.Canvas, "set_renderMode", 1), canvas, a1);
    int order = 32000;
    void* a2[] = {&order};
    call(meth(C.Canvas, "set_sortingOrder", 1), canvas, a2);
    void* scaler = comp(rootGO, C.Scaler);
    int scaleMode = 1;  // ScaleWithScreenSize
    void* a3[] = {&scaleMode};
    call(meth(C.Scaler, "set_uiScaleMode", 1), scaler, a3);
    V2 ref{1280, 720};
    void* a4[] = {&ref};
    call(meth(C.Scaler, "set_referenceResolution", 1), scaler, a4);
    comp(rootGO, C.Raycaster);
    keepAlive(rootGO);
    void* rootRT = call(meth(C.GameObject, "get_transform", 0), rootGO);

    // EventSystem (solo si el juego no tiene uno)
    void* cur = call(meth(C.EventSystem, "get_current", 0), nullptr);
    if (!cur) {
        void* esGO = newGO("CrewEventSystem");
        comp(esGO, C.EventSystem);
        comp(esGO, C.StdInput);
        keepAlive(esGO);
    }

    // Panel de mods
    El panel = mk(rootRT, "CrewPanel", {0.5f, 0.5f}, {0.5f, 0.5f}, {0.5f, 0.5f}, {0, 0}, {760, 560});
    addImage(panel, {0.f, 0.f, 0.f, 0.85f});
    g_panel = panel.go;

    El title = mk(panel.rt, "Title", {0.5f, 1}, {0.5f, 1}, {0.5f, 1}, {0, -14}, {700, 50});
    addText(title, "CrewLoader - Mods", 32, 4);

    const size_t kMaxRows = 7;
    if (g_mods.empty()) {
        El none = mk(panel.rt, "Empty", {0.5f, 0.5f}, {0.5f, 0.5f}, {0.5f, 0.5f}, {0, 0}, {700, 60});
        addText(none, "No hay mods importados", 26, 4);
    }
    g_rows.assign(g_mods.size(), Row{nullptr, nullptr});
    for (size_t i = 0; i < g_mods.size() && i < kMaxRows; ++i) {
        float y = -80.f - 56.f * (float)i;
        El name = mk(panel.rt, "ModName", {0, 1}, {0, 1}, {0, 1}, {30, y}, {480, 48});
        std::string label = g_mods[i].name + " v" + g_mods[i].version;
        addText(name, label.c_str(), 26, 3);
        const Mod& m = g_mods[i];
        Btn b = mkButton(panel.rt, "ModToggle", m.enabled ? "ON" : "OFF", {0, 1}, {0, 1}, {0, 1},
                         {540, y}, {180, 48}, m.enabled ? kBlue : kGray, [i]() { onToggle(i); });
        g_rows[i] = {b.img, b.text};
    }

    El hint = mk(panel.rt, "Hint", {0.5f, 0}, {0.5f, 0}, {0.5f, 0}, {0, 76}, {700, 30});
    addText(hint, "Para desactivar un mod ya cargado, reinicia el juego", 18, 4);

    mkButton(panel.rt, "Close", "Cerrar", {0.5f, 0}, {0.5f, 0}, {0.5f, 0}, {0, 16}, {200, 52}, kBlue,
             []() { g_panelOpen = false; setActive(g_panel, false); });
    setActive(panel.go, false);

    // Boton flotante (arriba a la derecha)
    mkButton(rootRT, "CrewFloatingButton", "CREW", {1, 1}, {1, 1}, {1, 1}, {-24, -24}, {130, 64},
             kBlue, []() { g_panelOpen = !g_panelOpen; setActive(g_panel, g_panelOpen); });

    LOGI("menu en juego creado (%s)", g_fail ? "CON ERRORES" : "ok");
    return !g_fail;
}

// ===================================================================== tick en hilo principal
static void* g_tickDelegate = nullptr;
static bool g_tickDone = false;

static void tick() {
    if (g_tickDone) return;
    g_tickDone = true;
    bool ok = buildUI();
    g_fail = false;
    void* a[] = {g_tickDelegate};
    call(meth(C.Application, "remove_onBeforeRender", 1), nullptr, a);
    if (!ok) reportMenuFailed();
}

static bool subscribeTick() {
    g_fail = false;
    g_tickDelegate = makeAction(tick);
    void* a[] = {g_tickDelegate};
    call(meth(C.Application, "add_onBeforeRender", 1), nullptr, a);
    return !g_fail;
}

// ===================================================================== hilo del loader
static void loaderMain() {
    LOGI("loader iniciado, home=%s", g_home.c_str());

    void* h = nullptr;
    for (int i = 0; i < 3000 && !h; ++i) {  // hasta ~5 min
        h = dlopen("libil2cpp.so", RTLD_NOW | RTLD_NOLOAD);
        if (!h) sleepMs(100);
    }
    if (!h) { LOGE("libil2cpp.so nunca cargo"); reportMenuFailed(); return; }
    LOGI("libil2cpp.so detectada");
    if (!resolveApi(h)) { reportMenuFailed(); return; }

    void* dom = nullptr;
    for (int i = 0; i < 3000 && !dom; ++i) {
        dom = p_domain_get();
        if (!dom) sleepMs(100);
    }
    if (!dom) { LOGE("il2cpp_domain_get() siempre null"); reportMenuFailed(); return; }
    g_domain = dom;
    LOGI("il2cpp_domain_get() listo");
    sleepMs(2000);  // deja que Unity termine de registrar assemblies
    p_thread_attach(dom);

    readManifest();
    for (auto& m : g_mods)
        if (m.enabled) loadMod(m);

    if (access("/storage/emulated/0/CrewLoader/disable_ui", F_OK) == 0) {
        LOGW("disable_ui presente: uso el menu Android de respaldo");
        reportMenuFailed();
        return;
    }
    if (!prepareClasses() || !subscribeTick()) {
        LOGE("no pude enganchar el hilo principal de Unity");
        reportMenuFailed();
    }
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    JNIEnv* env = nullptr;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) return JNI_ERR;
    jclass c = env->FindClass("com/crewloader/boot/Boot");
    if (c) {
        g_bootCls = (jclass)env->NewGlobalRef((jobject)c);
        g_menuFailed = env->GetStaticMethodID(c, "menuFailed", "()V");
    }
    if (env->ExceptionCheck()) env->ExceptionClear();

    const char* home = getenv("CREW_HOME");
    g_home = home ? home : "/data/data/com.crewloader.app/files";
    g_api.version = CREW_API_VERSION;
    g_api.vm = vm;
    g_api.log = apiLog;

    std::thread(loaderMain).detach();
    return JNI_VERSION_1_6;
}
