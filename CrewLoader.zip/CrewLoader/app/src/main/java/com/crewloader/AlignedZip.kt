package com.crewloader

import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Escritor de ZIP/APK que alinea las entradas sin comprimir:
 * 4096 bytes para .so y 4 bytes para el resto (resources.arsc lo exige).
 */
class AlignedZip(file: File) : Closeable {
    private class Counter(o: OutputStream) : FilterOutputStream(o) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private val counter = Counter(BufferedOutputStream(FileOutputStream(file), 1 shl 16))
    private val zos = ZipOutputStream(counter).apply { setLevel(Deflater.BEST_SPEED) }

    private fun beginStored(name: String, size: Long, crc: Long) {
        val e = ZipEntry(name).apply {
            method = ZipEntry.STORED; this.size = size; compressedSize = size; this.crc = crc
        }
        val align = if (name.endsWith(".so")) 4096 else 4
        val header = 30 + name.toByteArray(Charsets.UTF_8).size
        var pad = ((align - ((counter.count + header) % align)) % align).toInt()
        if (pad in 1..3) pad += align
        if (pad > 0) {
            val x = ByteArray(pad)
            x[0] = 0x35; x[1] = 0xD9.toByte()
            x[2] = ((pad - 4) and 0xFF).toByte(); x[3] = (((pad - 4) shr 8) and 0xFF).toByte()
            e.extra = x
        }
        zos.putNextEntry(e)
    }

    fun putStored(name: String, data: ByteArray) {
        beginStored(name, data.size.toLong(), CRC32().apply { update(data) }.value)
        zos.write(data)
        zos.closeEntry()
    }

    fun copy(z: ZipFile, e: ZipEntry) {
        if (e.method == ZipEntry.STORED) {
            beginStored(e.name, e.size, e.crc)
        } else {
            zos.putNextEntry(ZipEntry(e.name).apply { method = ZipEntry.DEFLATED })
        }
        if (!e.isDirectory) z.getInputStream(e).use { it.copyTo(zos) }
        zos.closeEntry()
    }

    override fun close() = zos.close()
}
