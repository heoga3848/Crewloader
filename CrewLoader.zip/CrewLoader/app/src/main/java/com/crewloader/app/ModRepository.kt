package com.crewloader.app

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.Process
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

data class ModInfo(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val file: File,
    var enabled: Boolean,
)

/**
 * Lista/importa/borra mods (.crewag) y mantiene filesDir/mods.json, que lee el loader nativo.
 * mods.json es la fuente de verdad del estado activado/desactivado.
 */
class ModRepository(private val ctx: Context) {

    companion object {
        private val ID_RE = Regex("[A-Za-z0-9._-]{1,64}")
    }

    val modsDir: File
        get() = File(Environment.getExternalStorageDirectory(), "CrewLoader/mods").apply { mkdirs() }

    private val manifest get() = File(ctx.filesDir, "mods.json")
    private val libRoot get() = File(ctx.filesDir, "modlibs")
    private val abi get() = if (Process.is64Bit()) "arm64-v8a" else "armeabi-v7a"

    private fun readEnabled(): Map<String, Boolean> = try {
        val arr = JSONObject(manifest.readText()).getJSONArray("mods")
        (0 until arr.length()).associate {
            val o = arr.getJSONObject(it)
            o.getString("id") to o.optBoolean("enabled", true)
        }
    } catch (_: Exception) {
        emptyMap()
    }

    private fun readMeta(file: File): ModInfo? = try {
        ZipFile(file).use { z ->
            val e = z.getEntry("mod.json") ?: return null
            val o = JSONObject(z.getInputStream(e).bufferedReader().readText())
            val id = o.getString("id")
            if (!ID_RE.matches(id)) return null
            ModInfo(
                id = id,
                name = o.optString("name", id),
                version = o.optString("version", "?"),
                author = o.optString("author", "?"),
                file = file,
                enabled = true,
            )
        }
    } catch (_: Exception) {
        null
    }

    fun list(): List<ModInfo> {
        val state = readEnabled()
        return (modsDir.listFiles { f -> f.isFile && f.extension == "crewag" } ?: emptyArray())
            .mapNotNull { readMeta(it) }
            .onEach { it.enabled = state[it.id] ?: true }
            .sortedBy { it.name.lowercase() }
    }

    fun setEnabled(id: String, on: Boolean) {
        val mods = list()
        mods.forEach { if (it.id == id) it.enabled = on }
        write(mods)
    }

    /** Extrae las .so del ABI actual y reescribe mods.json. Llamar antes de JUGAR. */
    fun sync() = write(list())

    fun import(uri: Uri): Result<ModInfo> = runCatching {
        val tmp = File(ctx.cacheDir, "import.crewag")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        val meta = readMeta(tmp) ?: error("Archivo invalido: falta mod.json o el id no es valido")
        val dest = File(modsDir, "${meta.id}.crewag")
        dest.delete()
        tmp.copyTo(dest, overwrite = true)
        tmp.delete()
        sync()
        meta.copy(file = dest)
    }

    /** Borra las .so extraidas y las vuelve a extraer. */
    fun clearCache() {
        libRoot.deleteRecursively()
        sync()
    }

    fun delete(mod: ModInfo) {
        mod.file.delete()
        File(libRoot, mod.id).deleteRecursively()
        sync()
    }

    private fun write(mods: List<ModInfo>) {
        val arr = JSONArray()
        for (m in mods) {
            arr.put(
                JSONObject()
                    .put("id", m.id).put("name", m.name).put("version", m.version)
                    .put("author", m.author).put("lib", extractLib(m)).put("enabled", m.enabled)
            )
        }
        manifest.writeText(JSONObject().put("mods", arr).toString())
    }

    /** Devuelve la ruta de la primera .so del ABI actual ("" si el mod no trae una). */
    private fun extractLib(mod: ModInfo): String = try {
        ZipFile(mod.file).use { z ->
            val entries = z.entries().asSequence()
                .filter { !it.isDirectory && it.name.startsWith("lib/$abi/") && it.name.endsWith(".so") }
                .toList()
            if (entries.isEmpty()) return ""
            val dir = File(libRoot, mod.id).apply { mkdirs() }
            var first = ""
            for (e in entries) {
                val out = File(dir, e.name.substringAfterLast('/'))
                if (!out.exists() || out.length() != e.size || out.lastModified() < mod.file.lastModified()) {
                    out.delete()
                    z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                }
                out.setReadOnly()  // Android 14+: el codigo cargado dinamicamente debe ser de solo lectura
                if (first.isEmpty()) first = out.absolutePath
            }
            first
        }
    } catch (_: Exception) {
        ""
    }
}
