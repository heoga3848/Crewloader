package com.crewloader

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.io.File

/** Instala una lista de APK (base + splits) con PackageInstaller. */
class Installer(private val ctx: Context, private val log: (String) -> Unit) {
    private val action = "com.crewloader.INSTALL_RESULT"

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (val s = i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                    val confirm = IntentCompat.getParcelableExtra(i, Intent.EXTRA_INTENT, Intent::class.java)
                    confirm?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (confirm != null) c.startActivity(confirm)
                }
                PackageInstaller.STATUS_SUCCESS -> log("Instalado. Ya puedes tocar «Jugar».")
                else -> log("Falló la instalación ($s): ${i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)}")
            }
        }
    }

    fun register() = ContextCompat.registerReceiver(
        ctx, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED
    )

    fun unregister() = try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}

    fun install(apks: List<File>, pkg: String) {
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setAppPackageName(pkg)
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apks.forEachIndexed { i, f ->
                f.inputStream().use { input ->
                    s.openWrite(if (i == 0) "base.apk" else "split_$i.apk", 0, f.length()).use { out ->
                        input.copyTo(out)
                        s.fsync(out)
                    }
                }
            }
            val intent = Intent(action).setPackage(ctx.packageName)
            val pending = PendingIntent.getBroadcast(
                ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            s.commit(pending.intentSender)
        }
    }
}
