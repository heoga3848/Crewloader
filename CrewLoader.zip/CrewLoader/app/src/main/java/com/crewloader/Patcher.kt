package com.crewloader

import android.content.Context
import com.android.apksig.ApkSigner
import java.io.File
import java.util.zip.ZipFile

/**
 * Parchea los APK de Among Us:
 *   lib/<abi>/libmain.so       -> proxy de CrewLoader
 *   lib/<abi>/libmain_orig.so  -> libmain.so original del juego
 *   lib/<abi>/libcrewmodN.so   -> librerías nativas de los mods activos
 * y vuelve a firmar todos los APK con la clave de esta instalación.
 */
class Patcher(private val ctx: Context, private val log: (String) -> Unit) {
    private val abis = listOf("arm64-v8a", "armeabi-v7a")
    private val sigFiles = Regex("META-INF/.*(\\.SF|\\.RSA|\\.DSA|\\.EC|MANIFEST\\.MF)$")
    private val libMain = Regex("lib/([^/]+)/libmain\\.so")

    fun patch(originals: List<File>, mods: List<File>, outDir: File): List<File> {
        outDir.deleteRecursively(); outDir.mkdirs()
        val proxies = loadProxies()
        val modLibs = loadModLibs(mods)
        val signer = Keys.config(ctx)
        var patchedAny = false
        val result = mutableListOf<File>()
        originals.forEachIndexed { i, src ->
            log("Parcheando ${i + 1}/${originals.size}…")
            val unsigned = File(ctx.cacheDir, "unsigned_$i.apk")
            if (rewrite(src, unsigned, proxies, modLibs)) patchedAny = true
            val out = File(outDir, src.name)
            log("Firmando ${i + 1}/${originals.size}…")
            ApkSigner.Builder(listOf(signer))
                .setInputApk(unsigned).setOutputApk(out)
                .setMinSdkVersion(28)
                .setV1SigningEnabled(false).setV2SigningEnabled(true).setV3SigningEnabled(true)
                .build().sign()
            unsigned.delete()
            result += out
        }
        if (!patchedAny) error("No encontré libmain.so en el juego (versión de Among Us no compatible).")
        return result
    }

    private fun loadProxies(): Map<String, ByteArray> {
        val m = mutableMapOf<String, ByteArray>()
        ZipFile(ctx.applicationInfo.sourceDir).use { z ->
            for (abi in abis) z.getEntry("lib/$abi/libmain.so")?.let { m[abi] = z.getInputStream(it).readBytes() }
        }
        return m
    }

    /** abi -> lista de (índice del mod, bytes del .so) */
    private fun loadModLibs(mods: List<File>): Map<String, List<Pair<Int, ByteArray>>> {
        val m = abis.associateWith { mutableListOf<Pair<Int, ByteArray>>() }
        mods.forEachIndexed { idx, f ->
            ZipFile(f).use { z ->
                for (abi in abis) {
                    val e = z.entries().asSequence().firstOrNull {
                        !it.isDirectory && it.name.startsWith("lib/$abi/") && it.name.endsWith(".so")
                    }
                    if (e != null) m.getValue(abi).add(idx to z.getInputStream(e).readBytes())
                }
            }
        }
        return m
    }

    private fun rewrite(
        src: File, dst: File,
        proxies: Map<String, ByteArray>, modLibs: Map<String, List<Pair<Int, ByteArray>>>
    ): Boolean {
        var patched = false
        ZipFile(src).use { z ->
            AlignedZip(dst).use { out ->
                for (e in z.entries()) {
                    if (sigFiles.matches(e.name)) continue
                    val abi = libMain.matchEntire(e.name)?.groupValues?.get(1)
                    if (abi != null && proxies.containsKey(abi)) {
                        out.putStored("lib/$abi/libmain_orig.so", z.getInputStream(e).readBytes())
                        out.putStored(e.name, proxies.getValue(abi))
                        modLibs[abi]?.forEach { (i, bytes) -> out.putStored("lib/$abi/libcrewmod$i.so", bytes) }
                        patched = true
                    } else {
                        out.copy(z, e)
                    }
                }
            }
        }
        return patched
    }
}
