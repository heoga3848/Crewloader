package com.crewloader

import android.app.Activity
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.pm.ApplicationInfo
import android.content.res.Resources
import android.os.Build
import android.util.Log
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import dalvik.system.PathClassLoader

/**
 * Hospeda Among Us dentro del proceso de CrewLoader SIN tocar el APK original:
 * crea un ClassLoader que ve (a) las clases/libs del juego instalado y (b) libcrewloader.so,
 * y arranca UnityPlayer desde ahi. El juego sigue siendo el de Play Store.
 */
class GameActivity : Activity() {

    companion object {
        const val GAME = "com.innersloth.spacemafia"
        private const val TAG = "CrewLoader"
    }

    private var gameInfo: ApplicationInfo? = null
    private var gameRes: Resources? = null
    private var boot: Class<*>? = null
    private var player: Any? = null

    // Unity lee estas rutas del Context: se las damos del juego instalado (solo despues de montar la vista).
    override fun getApplicationInfo(): ApplicationInfo = gameInfo ?: super.getApplicationInfo()
    override fun getPackageCodePath(): String = gameInfo?.sourceDir ?: super.getPackageCodePath()
    override fun getResources(): Resources = gameRes ?: super.getResources()
    override fun getAssets(): AssetManager = gameRes?.assets ?: super.getAssets()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this)
        setContentView(root)
        try {
            val ai = packageManager.getApplicationInfo(GAME, 0)
            val res = packageManager.getResourcesForApplication(ai)
            val abi = Build.SUPPORTED_ABIS[0]

            val gameApks = listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
            val nativePaths = listOf(ai.nativeLibraryDir) +
                gameApks.map { "$it!/lib/$abi" } +
                listOf(super.getApplicationInfo().nativeLibraryDir)
            val dexPaths = listOf(super.getApplicationInfo().sourceDir) + gameApks

            // parent = BootClassLoader: nuestra clase Bootstrap se define en ESTE loader,
            // asi libcrewloader.so y las libs de Unity comparten namespace nativo.
            val loader = PathClassLoader(
                dexPaths.joinToString(":"),
                nativePaths.joinToString(":"),
                classLoader.parent
            )
            val b = loader.loadClass("com.crewloader.Bootstrap")
            boot = b

            // A partir de aqui el "Context" se comporta como el del juego.
            gameInfo = ai
            gameRes = res

            val p = b.getMethod(
                "createPlayer",
                Activity::class.java, String::class.java, String::class.java, String::class.java
            ).invoke(
                null, this,
                ModStore.modsDir.absolutePath,
                ModStore.config.absolutePath,
                cacheDir.absolutePath
            )
            player = p
            val view = b.getMethod("viewOf", Any::class.java).invoke(null, p) as View
            root.addView(
                view,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            view.requestFocus()
        } catch (t: Throwable) {
            Log.e(TAG, "No se pudo iniciar el juego", t)
            val c = t.cause ?: t
            Toast.makeText(this, "Error: ${c.javaClass.simpleName}: ${c.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun life(name: String) {
        val p = player ?: return
        try {
            boot?.getMethod("lifecycle", Any::class.java, String::class.java)?.invoke(null, p, name)
        } catch (_: Throwable) {
        }
    }

    private fun inject(e: InputEvent): Boolean {
        val p = player ?: return false
        return try {
            boot?.getMethod("inject", Any::class.java, InputEvent::class.java)?.invoke(null, p, e) as? Boolean ?: false
        } catch (_: Throwable) {
            false
        }
    }

    override fun onStart() { super.onStart(); life("start") }
    override fun onResume() { super.onResume(); life("resume") }
    override fun onPause() { life("pause"); super.onPause() }
    override fun onStop() { life("stop"); super.onStop() }
    override fun onDestroy() { life("destroy"); super.onDestroy() }
    override fun onLowMemory() { super.onLowMemory(); life("lowMemory") }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        val p = player
        if (p != null) {
            try {
                boot?.getMethod("focus", Any::class.java, Boolean::class.javaPrimitiveType)?.invoke(null, p, hasFocus)
            } catch (_: Throwable) {
            }
        }
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val p = player ?: return
        try {
            boot?.getMethod("config", Any::class.java, Configuration::class.java)?.invoke(null, p, newConfig)
        } catch (_: Throwable) {
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean =
        if (event.action == KeyEvent.ACTION_MULTIPLE) inject(event) else super.dispatchKeyEvent(event)

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean = inject(event) || super.onKeyUp(keyCode, event)
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = inject(event) || super.onKeyDown(keyCode, event)
    override fun onTouchEvent(event: MotionEvent): Boolean = inject(event) || super.onTouchEvent(event)
    override fun onGenericMotionEvent(event: MotionEvent): Boolean = inject(event) || super.onGenericMotionEvent(event)
}
