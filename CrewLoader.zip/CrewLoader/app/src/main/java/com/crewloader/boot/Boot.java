package com.crewloader.boot;

/**
 * Esta clase la carga el ClassLoader del JUEGO (ver GameLoader). Asi libcrewloader.so queda en el
 * mismo namespace del linker que libil2cpp.so y puede encontrarla con dlopen(RTLD_NOLOAD).
 */
public final class Boot {
    /** La asigna GameActivity por reflexion; se invoca si el menu Unity no se pudo crear. */
    public static volatile Runnable onMenuFailed;

    static {
        System.loadLibrary("crewloader");
    }

    private Boot() {}

    /** Llamada desde el codigo nativo (JNI). */
    public static void menuFailed() {
        Runnable r = onMenuFailed;
        if (r != null) r.run();
    }
}
