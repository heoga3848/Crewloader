package com.crewloader

import android.content.Context
import com.android.apksig.ApkSigner
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/** Clave de firma propia de cada instalación (se genera la primera vez). */
object Keys {
    fun sha256(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    private fun files(ctx: Context) = File(ctx.filesDir, "sign.pk8") to File(ctx.filesDir, "sign.crt")

    @Synchronized
    private fun ensure(ctx: Context) {
        val (kf, cf) = files(ctx)
        if (kf.exists() && cf.exists()) return
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=CrewLoader")
        val now = System.currentTimeMillis()
        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now), Date(now - 86_400_000L),
            Date(now + 30L * 365 * 86_400_000L), name, kp.public
        )
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        kf.writeBytes(kp.private.encoded)
        cf.writeBytes(cert.encoded)
    }

    private fun cert(ctx: Context): X509Certificate {
        ensure(ctx)
        return CertificateFactory.getInstance("X.509").generateCertificate(files(ctx).second.inputStream()) as X509Certificate
    }

    fun certSha256(ctx: Context) = sha256(cert(ctx).encoded)

    fun config(ctx: Context): ApkSigner.SignerConfig {
        val c = cert(ctx)
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(files(ctx).first.readBytes()))
        return ApkSigner.SignerConfig.Builder("crewloader", key, listOf(c)).build()
    }
}
