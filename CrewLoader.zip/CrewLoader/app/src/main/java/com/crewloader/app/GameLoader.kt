package com.crewloader.app

import dalvik.system.PathClassLoader

/**
 * ClassLoader del juego: ve el APK (y splits) de Among Us ya instalado, mas el nuestro.
 * Las clases de com.crewloader.boot.* se definen AQUI (hijo primero) para que
 * System.loadLibrary("crewloader") use el namespace nativo de este loader.
 */
class GameLoader(dexPath: String, libPath: String, parent: ClassLoader) :
    PathClassLoader(dexPath, libPath, parent) {

    override fun loadClass(name: String, resolve: Boolean): Class<*> {
        if (name.startsWith("com.crewloader.boot.")) {
            synchronized(getClassLoadingLock(name)) {
                findLoadedClass(name)?.let { return it }
                return try {
                    findClass(name)
                } catch (e: ClassNotFoundException) {
                    super.loadClass(name, resolve)
                }
            }
        }
        return super.loadClass(name, resolve)
    }
}
