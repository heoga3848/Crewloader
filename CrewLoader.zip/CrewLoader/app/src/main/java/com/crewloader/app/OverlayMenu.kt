package com.crewloader.app

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * Menu de RESPALDO en vistas Android. Solo aparece si el menu real de Unity (loader.cpp)
 * no pudo crearse (UnityEngine.UI recortado, metodo no encontrado, etc.).
 */
class OverlayMenu(private val act: Activity) {

    private var shown = false
    private val blue = Color.parseColor("#1A73F2")

    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit) = Button(act).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(blue)
        setOnClickListener { onClick() }
    }

    fun show() {
        if (shown) return
        shown = true
        val repo = ModRepository(act)
        val frame = FrameLayout(act)

        val panel = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#D9000000"))
            setPadding(dp(16), dp(16), dp(16), dp(16))
            visibility = View.GONE
        }
        panel.addView(TextView(act).apply {
            text = "CrewLoader - Mods"
            textSize = 22f
            setTextColor(Color.WHITE)
        })
        val rows = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(ScrollView(act).apply { addView(rows) }, LinearLayout.LayoutParams(-1, 0, 1f))
        panel.addView(TextView(act).apply {
            text = "Los cambios se aplican al reiniciar el juego"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        })
        panel.addView(button("Cerrar") { panel.visibility = View.GONE })

        val fab = button("CREW") {
            rows.removeAllViews()
            val mods = repo.list()
            if (mods.isEmpty()) rows.addView(TextView(act).apply { text = "No hay mods"; setTextColor(Color.WHITE) })
            for (m in mods) {
                rows.addView(Switch(act).apply {
                    text = "${m.name} v${m.version}"
                    setTextColor(Color.WHITE)
                    isChecked = m.enabled
                    setOnCheckedChangeListener { _, on -> repo.setEnabled(m.id, on) }
                })
            }
            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        frame.addView(panel, FrameLayout.LayoutParams(dp(420), dp(300), Gravity.CENTER))
        frame.addView(fab, FrameLayout.LayoutParams(dp(110), dp(52), Gravity.TOP or Gravity.END).apply {
            setMargins(dp(8), dp(8), dp(8), dp(8))
        })
        act.addContentView(frame, FrameLayout.LayoutParams(-1, -1))
    }
}
