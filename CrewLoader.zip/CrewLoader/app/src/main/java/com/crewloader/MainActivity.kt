package com.crewloader

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.view.LayoutInflater
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val pickCode = 42
    private var askedPerm = false

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.modList)
        status = findViewById(R.id.tvStatus)
        findViewById<Button>(R.id.btnImport).setOnClickListener { pickFile() }
        findViewById<Button>(R.id.btnPlay).setOnClickListener { play() }
    }

    override fun onResume() {
        super.onResume()
        if (hasStorage()) {
            ModStore.ensureDirs()
        } else if (!askedPerm) {
            askedPerm = true
            askStorage()
        }
        refresh()
    }

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            Toast.makeText(this, "Activa 'Permitir acceso a todos los archivos' para CrewLoader", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1
            )
        }
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r, p, g)
        onResume()
    }

    private fun refresh() {
        list.removeAllViews()
        val abi = Build.SUPPORTED_ABIS[0]
        val mods = if (hasStorage()) ModStore.list(abi) else emptyList()
        val enabled = ModStore.enabled()
        status.text = "ABI: $abi  |  Mods: ${mods.size}  |  Carpeta: ${ModStore.modsDir.path}"
        val inf = LayoutInflater.from(this)
        for (m in mods) {
            val v = inf.inflate(R.layout.item_mod, list, false)
            v.findViewById<TextView>(R.id.tvName).text = "${m.name}  v${m.version}"
            v.findViewById<TextView>(R.id.tvInfo).text =
                "Autor: ${m.author}\nID: ${m.id}" + if (m.hasLibForDevice) "" else "\n(sin lib para $abi)"
            val sw = v.findViewById<Switch>(R.id.swEnabled)
            sw.isChecked = m.id in enabled
            sw.setOnCheckedChangeListener { _, on -> ModStore.setEnabled(m.id, on) }
            v.findViewById<Button>(R.id.btnDelete).setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Eliminar ${m.name}?")
                    .setPositiveButton("Eliminar") { _, _ ->
                        ModStore.setEnabled(m.id, false)
                        m.file.delete()
                        refresh()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
            list.addView(v)
        }
    }

    private fun pickFile() {
        if (!hasStorage()) {
            askStorage(); return
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, pickCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val err = ModStore.import(this, uri)
            Toast.makeText(this, err ?: "Mod importado", Toast.LENGTH_LONG).show()
            refresh()
        }
    }

    private fun play() {
        try {
            packageManager.getPackageInfo(GameActivity.GAME, 0)
        } catch (_: Exception) {
            Toast.makeText(this, "Among Us no esta instalado (Play Store)", Toast.LENGTH_LONG).show()
            return
        }
        if (!hasStorage()) {
            askStorage(); return
        }
        startActivity(Intent(this, GameActivity::class.java))
    }
}
