package com.crewloader

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {

    private val game = "com.innersloth.spacemafia"
    private val modsDir by lazy { File(filesDir, "crewag").apply { mkdirs() } }
    private val origDir by lazy { File(filesDir, "original") }
    private val patchedDir by lazy { File(filesDir, "patched") }
    private val prefs by lazy { getSharedPreferences("crewloader", MODE_PRIVATE) }
    private lateinit var installer: Installer
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var applyBtn: Button
    private lateinit var list: LinearLayout
    private var pendingInstall = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { importMod(it) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installer = Installer(this, ::log).also { it.register() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        root.addView(TextView(this).apply { text = "CrewLoader"; textSize = 28f; setTextColor(Color.WHITE) })
        status = TextView(this).apply { setTextColor(Color.parseColor("#9AA3B2")); setPadding(0, dp(4), 0, dp(12)) }
        root.addView(status)
        applyBtn = btn("Aplicar mods e instalar") { onApplyClicked() }
        root.addView(applyBtn)
        root.addView(btn("Jugar") { launchGame() })
        root.addView(TextView(this).apply {
            text = "Mods (.crewag)"; textSize = 18f; setTextColor(Color.WHITE); setPadding(0, dp(20), 0, dp(4))
        })
        root.addView(btn("Añadir mod") { picker.launch(arrayOf("*/*")) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        logView = TextView(this).apply {
            setTextColor(Color.parseColor("#7DD3A8")); textSize = 12f; setPadding(0, dp(16), 0, 0)
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#12141C")); addView(root)
        })
        render()
    }

    override fun onResume() {
        super.onResume()
        if (pendingInstall) {
            if (signers() == null) {
                pendingInstall = false
                val files = patchedDir.listFiles()?.sortedBy { it.name }.orEmpty()
                if (files.isNotEmpty()) installer.install(files, game)
            } else {
                pendingInstall = false
                log("Desinstalación cancelada.")
            }
        }
        refreshStatus()
    }

    override fun onDestroy() { installer.unregister(); super.onDestroy() }

    private fun log(m: String) = runOnUiThread { logView.append(m + "\n") }

    // ---------- estado del juego ----------
    private fun signers(): Set<String>? = try {
        packageManager.getPackageInfo(game, PackageManager.GET_SIGNING_CERTIFICATES)
            .signingInfo?.apkContentsSigners?.map { Keys.sha256(it.toByteArray()) }?.toSet()
    } catch (e: PackageManager.NameNotFoundException) { null }

    private fun installedApks(): List<File> {
        val ai = packageManager.getApplicationInfo(game, 0)
        return (listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())).map { File(it) }
    }

    private fun refreshStatus() {
        val s = signers()
        status.text = if (s == null) "Among Us no está instalado."
        else {
            val v = packageManager.getPackageInfo(game, 0).versionName
            if (s == setOf(Keys.certSha256(this))) "Among Us $v · con CrewLoader" else "Among Us $v · original (sin mods)"
        }
    }

    // ---------- aplicar ----------
    private fun onApplyClicked() {
        val s = signers()
        val foreign = s != null && s != setOf(Keys.certSha256(this))
        if (foreign) {
            AlertDialog.Builder(this)
                .setTitle("Instalar versión con mods")
                .setMessage("Se desinstalará tu Among Us original y se instalará la versión con mods. " +
                    "Solo hace falta la primera vez. Se pierden los datos locales que no estén sincronizados con tu cuenta.")
                .setPositiveButton("Continuar") { _, _ -> runApply(true) }
                .setNegativeButton("Cancelar", null).show()
        } else runApply(false)
    }

    private fun runApply(foreign: Boolean) {
        applyBtn.isEnabled = false
        logView.text = ""
        thread {
            try {
                if (foreign) {
                    log("Guardando copia de los APK originales…")
                    origDir.deleteRecursively(); origDir.mkdirs()
                    installedApks().forEachIndexed { i, f -> f.copyTo(File(origDir, "%02d.apk".format(i))) }
                }
                val originals = origDir.listFiles()?.sortedBy { it.name }.orEmpty()
                if (originals.isEmpty())
                    error("No tengo los APK originales. Instala Among Us desde la Play Store y vuelve a intentarlo.")
                val enabled = mods().filter { it.nameWithoutExtension !in disabled() }
                log("Mods activos: ${enabled.size}")
                val out = Patcher(this, ::log).patch(originals, enabled, patchedDir)
                runOnUiThread {
                    if (foreign) {
                        pendingInstall = true
                        log("Confirma la desinstalación; después se instalará la versión con mods.")
                        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$game")))
                    } else {
                        log("Instalando…")
                        installer.install(out, game)
                    }
                }
            } catch (e: Throwable) {
                log("Error: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                runOnUiThread { applyBtn.isEnabled = true }
            }
        }
    }

    private fun launchGame() {
        val i = packageManager.getLaunchIntentForPackage(game)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Among Us no está instalado", Toast.LENGTH_SHORT).show()
    }

    // ---------- mods ----------
    private fun readManifest(file: File): JSONObject? = try {
        ZipFile(file).use { z ->
            val e = z.getEntry("mod.json") ?: return null
            val j = JSONObject(z.getInputStream(e).bufferedReader().readText())
            if (j.optString("id").isBlank() || j.optString("name").isBlank() || j.optString("version").isBlank()) null else j
        }
    } catch (e: Exception) { null }

    private fun importMod(uri: Uri) {
        val tmp = File(cacheDir, "import.crewag")
        contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        val m = readManifest(tmp)
        if (m == null) {
            Toast.makeText(this, "Archivo inválido: falta mod.json (id, name, version)", Toast.LENGTH_LONG).show()
            return
        }
        val id = m.getString("id").replace(Regex("[^A-Za-z0-9._-]"), "_")
        tmp.copyTo(File(modsDir, "$id.crewag"), overwrite = true)
        tmp.delete()
        render()
        log("Mod añadido. Pulsa «Aplicar mods e instalar» para que entre al juego.")
    }

    private fun disabled(): MutableSet<String> = prefs.getStringSet("disabled", emptySet())!!.toMutableSet()
    private fun mods() = modsDir.listFiles { f -> f.extension == "crewag" }?.sortedBy { it.name }.orEmpty()

    private fun render() {
        list.removeAllViews()
        val all = mods()
        if (all.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Aún no hay mods."; setTextColor(Color.parseColor("#9AA3B2")); setPadding(0, dp(8), 0, 0)
            })
            return
        }
        val off = disabled()
        all.forEach { file ->
            val m = readManifest(file)
            val id = file.nameWithoutExtension
            val on = id !in off
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            row.addView(TextView(this).apply {
                text = "${m?.optString("name") ?: id}  v${m?.optString("version") ?: "?"}\n" +
                    "${m?.optString("author", "") ?: ""} · ${if (on) "activo" else "apagado"}"
                setTextColor(if (on) Color.WHITE else Color.parseColor("#6B7280"))
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(btn(if (on) "Apagar" else "Activar") {
                val s = disabled(); if (on) s.add(id) else s.remove(id)
                prefs.edit().putStringSet("disabled", s).apply(); render()
            })
            row.addView(btn("Borrar") { file.delete(); render() })
            list.addView(row)
        }
    }
}
