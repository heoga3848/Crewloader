package com.crewloader.app

import android.app.Activity
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.res.AssetManager
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.os.Process
import android.system.Os
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.io.File

/**
 * Lanza Among Us DENTRO del proceso de CrewLoader (:game) usando el APK ya instalado:
 *  - NO se modifica, descomprime ni re-firma el APK del juego.
 *  - Un GameLoader (PathClassLoader) ve el APK + splits del juego y nuestra libcrewloader.so.
 *  - Esta Activity presta al UnityPlayer los assets/recursos del juego.
 * Es experimental: depende de la version de Unity de Among Us. Revisa logcat (tag CrewLoader).
 */
class GameActivity : Activity() {

    private var gameCtx: Context? = null
    private var gameInfo: ApplicationInfo? = null
    private var loader: GameLoader? = null
    private var player: Any? = null
    private var overlay: OverlayMenu? = null

    // Hasta que boot() termina se usan los valores normales (el tema ya quedo resuelto).
    override fun getAssets(): AssetManager = gameCtx?.assets ?: super.getAssets()
    override fun getResources(): Resources = gameCtx?.resources ?: super.getResources()
    override fun getPackageCodePath(): String = gameInfo?.sourceDir ?: super.getPackageCodePath()
    override fun getApplicationInfo(): ApplicationInfo = gameInfo ?: super.getApplicationInfo()
    override fun getClassLoader(): ClassLoader = loader ?: super.getClassLoader()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        getTheme()  // fuerza a resolver el tema con NUESTROS recursos antes de prestar los del juego
        try {
            boot()
        } catch (t: Throwable) {
            Log.e(TAG, "no se pudo iniciar el juego", t)
            Toast.makeText(this, "Error: ${t.javaClass.simpleName}: ${t.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun boot() {
        val info = packageManager.getApplicationInfo(GAME_PKG, 0)
        val gctx = createPackageContext(GAME_PKG, Context.CONTEXT_IGNORE_SECURITY)
        val own = super.getApplicationInfo()
        val abi = if (Process.is64Bit()) "arm64-v8a" else "armeabi-v7a"

        val gameApks = listOf(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())
        val dexPath = (gameApks + own.sourceDir).joinToString(":")
        val libPath = (gameApks.map { "$it!/lib/$abi" } +
            listOfNotNull(info.nativeLibraryDir) +
            File(filesDir, "modlibs").path +
            own.nativeLibraryDir).joinToString(":")
        Log.i(TAG, "dex=$dexPath")
        Log.i(TAG, "lib=$libPath")

        // El loader nativo lee esta variable para ubicar mods.json.
        Os.setenv("CREW_HOME", filesDir.absolutePath, true)

        val gl = GameLoader(dexPath, libPath, super.getClassLoader())
        // Esto ejecuta System.loadLibrary("crewloader") -> JNI_OnLoad -> arranca el hilo del loader.
        val boot = Class.forName("com.crewloader.boot.Boot", true, gl)
        boot.getField("onMenuFailed").set(null, Runnable { runOnUiThread { showFallbackMenu() } })

        loader = gl
        gameInfo = info
        gameCtx = gctx

        val upClass = gl.loadClass("com.unity3d.player.UnityPlayer")
        val ctor1 = upClass.constructors.firstOrNull {
            it.parameterTypes.size == 1 && it.parameterTypes[0] == Context::class.java
        }
        val p: Any = if (ctor1 != null) {
            ctor1.newInstance(this)
        } else {
            upClass.constructors.first {
                it.parameterTypes.size == 2 && it.parameterTypes[0] == Context::class.java
            }.newInstance(this, null)
        }
        player = p
        (p as? View)?.let {
            setContentView(it)
            it.requestFocus()
        } ?: Log.w(TAG, "UnityPlayer no es un View; esta version de Unity necesita otro camino")
    }

    private fun showFallbackMenu() {
        if (overlay == null) overlay = OverlayMenu(this)
        overlay?.show()
    }

    private fun callPlayer(name: String, vararg args: Any?) {
        val p = player ?: return
        try {
            p.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size }
                ?.invoke(p, *args)
        } catch (t: Throwable) {
            Log.w(TAG, "player.$name fallo: $t")
        }
    }

    override fun onStart() { super.onStart(); callPlayer("start") }
    override fun onResume() { super.onResume(); callPlayer("resume") }
    override fun onPause() { super.onPause(); callPlayer("pause") }
    override fun onStop() { super.onStop(); callPlayer("stop") }
    override fun onLowMemory() { super.onLowMemory(); callPlayer("lowMemory") }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        callPlayer("windowFocusChanged", hasFocus)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        callPlayer("configurationChanged", newConfig)
    }

    override fun onDestroy() {
        callPlayer("destroy")
        super.onDestroy()
        Process.killProcess(Process.myPid())  // Unity no se puede reiniciar dentro del mismo proceso
    }

    private companion object {
        const val TAG = "CrewLoader"
    }
}
