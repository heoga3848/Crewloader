package com.crewloader.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

const val GAME_PKG = "com.innersloth.spacemafia"

/** Pantallas: 0 = inicio, 1 = mods, 2 = ajustes (todo dibujado en codigo, sin librerias). */
class MainActivity : Activity() {

    private lateinit var repo: ModRepository
    private lateinit var root: FrameLayout
    private var screen = 0

    private val safeModeFile
        get() = File(Environment.getExternalStorageDirectory(), "CrewLoader/disable_ui")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG
        window.setBackgroundDrawable(ColorDrawable(Pal.BG))
        repo = ModRepository(this)
        root = FrameLayout(this)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (screen != 0) { screen = 0; render() } else super.onBackPressed()
    }

    private fun render() {
        when (screen) {
            0 -> showHome()
            1 -> showMods()
            else -> showSettings()
        }
    }

    private fun setScreen(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
    }

    // ------------------------------------------------------------------ permisos / estado
    private fun hasStorage() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 2
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) = render()

    private fun gameInstalled() = try {
        packageManager.getPackageInfo(GAME_PKG, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun play() {
        if (!hasStorage()) { requestStorage(); return }
        if (!gameInstalled()) {
            Toast.makeText(this, "Among Us no esta instalado", Toast.LENGTH_LONG).show()
            return
        }
        repo.sync()
        startActivity(Intent(this, GameActivity::class.java))
    }

    // ------------------------------------------------------------------ piezas reutilizables
    private fun pill(text: String, icon: Ic, filled: Boolean, onClick: () -> Unit): View {
        val fg = if (filled) Pal.ON_PRIMARY else Pal.PRIMARY
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = rippleBg(if (filled) Pal.PRIMARY else 0, uniform(dpf(100f)), if (filled) null else Pal.OUTLINE)
            addView(IconView(this@MainActivity, icon, fg), lp(dp(20), dp(20)).apply { rightMargin = dp(10) })
            addView(label(text, 16f, fg, true))
            setOnClickListener { onClick() }
        }
    }

    private fun header(text: String): View =
        label(text, 15f, Pal.TEXT, true).apply { setPadding(dp(12), dp(22), 0, dp(8)) }

    private fun row(
        i: Int, n: Int, title: String, sub: String? = null, icon: Ic? = null,
        iconColor: Int = Pal.TEXT, trailing: View? = null, onClick: (() -> Unit)? = null,
    ): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(if (sub != null) 76 else 64)
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = groupBg(i, n)
            if (onClick != null) setOnClickListener { onClick() }
        }
        if (icon != null) {
            r.addView(IconView(this, icon, iconColor), lp(dp(24), dp(24)).apply { rightMargin = dp(16) })
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 16f, Pal.TEXT, true))
        if (sub != null) col.addView(label(sub, 13f, Pal.TEXT2))
        r.addView(col, lp(0, -2).apply { weight = 1f })
        if (trailing != null) r.addView(trailing)
        r.layoutParams = lp(-1, -2).apply { topMargin = dp(2) }
        return r
    }

    private fun page(title: String, content: LinearLayout): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(12), dp(16), dp(8))
        }
        val back = IconView(this, Ic.BACK).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rippleBg(0, uniform(dpf(24f)))
            setOnClickListener { screen = 0; render() }
        }
        bar.addView(back, lp(dp(48), dp(48)))
        bar.addView(label(title, 22f, Pal.TEXT, true), lp(-2, -2).apply { leftMargin = dp(8) })
        col.addView(bar)
        content.setPadding(dp(16), 0, dp(16), dp(24))
        col.addView(ScrollView(this).apply { addView(content) }, lp(-1, 0).apply { weight = 1f })
        return col
    }

    // ------------------------------------------------------------------ inicio
    private fun showHome() {
        screen = 0
        val storage = hasStorage()
        val mods = if (storage) repo.list() else emptyList()
        val enabled = mods.count { it.enabled }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), 0, dp(24), dp(48))
        }

        val brand = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        brand.addView(LogoView(this), lp(dp(68), dp(68)))
        brand.addView(label("CrewLoader", 38f, 0xFFE3E3E3.toInt(), true), lp(-2, -2).apply { leftMargin = dp(10) })
        col.addView(brand)

        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        actions.addView(pill("Jugar", Ic.PLAY, true) { play() }, lp(dp(176), dp(58)))
        val gear = IconView(this, Ic.GEAR).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rippleBg(0, uniform(dpf(24f)))
            setOnClickListener { screen = 2; render() }
        }
        actions.addView(gear, lp(dp(48), dp(48)).apply { leftMargin = dp(16) })
        col.addView(actions, lp(-2, -2).apply { topMargin = dp(28) })

        col.addView(
            pill("Mods  \u00b7  $enabled/${mods.size}", Ic.FOLDER, false) { screen = 1; render() },
            lp(dp(240), dp(48)).apply { topMargin = dp(14) }
        )

        val installed = gameInstalled()
        val status: TextView = when {
            !installed -> label("Among Us no est\u00e1 instalado", 13f, Pal.ERROR)
            !storage -> label("Falta el permiso de archivos. Toca para concederlo.", 13f, Pal.ERROR)
                .apply { setOnClickListener { requestStorage() } }
            else -> label("Among Us detectado", 13f, Pal.TEXT2)
        }
        status.gravity = Gravity.CENTER
        col.addView(status, lp(-2, -2).apply { topMargin = dp(20) })
        setScreen(col)
    }

    // ------------------------------------------------------------------ mods
    private fun showMods() {
        screen = 1
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (!hasStorage()) {
            c.addView(row(0, 1, "Falta el permiso de archivos", "Toca para concederlo", Ic.FOLDER) { requestStorage() })
            setScreen(page("Mods", c))
            return
        }
        c.addView(row(0, 1, "Importar .crewag", "Se guarda en CrewLoader/mods", Ic.PLUS) {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 1
            )
        })
        c.addView(header("Instalados"))

        val mods = repo.list()
        if (mods.isEmpty()) {
            c.addView(row(0, 1, "No hay mods", "Importa un archivo .crewag para empezar."))
        }
        mods.forEachIndexed { i, m ->
            val sw = M3Switch(this).apply {
                set(m.enabled)
                onChange = { on -> repo.setEnabled(m.id, on) }
            }
            val trash = IconView(this, Ic.TRASH, Pal.ERROR).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rippleBg(0, uniform(dpf(20f)))
                setOnClickListener { confirmDelete(m) }
            }
            val trailing = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(trash, lp(dp(40), dp(40)).apply { rightMargin = dp(8) })
                addView(sw)
            }
            c.addView(row(i, mods.size, m.name, "v${m.version}  \u00b7  ${m.author}", trailing = trailing) {
                sw.performClick()
            })
        }
        setScreen(page("Mods", c))
    }

    private fun confirmDelete(m: ModInfo) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Eliminar mod")
            .setMessage("\u00bfEliminar ${m.name}?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Eliminar") { _, _ -> repo.delete(m); render() }
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (requestCode != 1 || resultCode != RESULT_OK) return
        repo.import(uri)
            .onSuccess { Toast.makeText(this, "Importado: ${it.name}", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, it.message ?: "Error al importar", Toast.LENGTH_LONG).show() }
        render()
    }

    // ------------------------------------------------------------------ ajustes
    private fun showSettings() {
        screen = 2
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val storage = hasStorage()

        c.addView(header("General"))
        c.addView(row(0, 2, "Acceso a archivos", if (storage) "Concedido" else "Falta. Toca para concederlo", Ic.FOLDER) {
            if (!hasStorage()) requestStorage()
        })
        val path = repo.modsDir.absolutePath
        c.addView(row(1, 2, "Carpeta de mods", path, Ic.FOLDER) {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("ruta", path))
            Toast.makeText(this, "Ruta copiada", Toast.LENGTH_SHORT).show()
        })

        c.addView(header("Juego"))
        val sw = M3Switch(this).apply {
            set(safeModeFile.exists())
            onChange = { on ->
                if (!hasStorage()) {
                    set(!on)
                    requestStorage()
                } else runCatching {
                    if (on) { safeModeFile.parentFile?.mkdirs(); safeModeFile.createNewFile() } else safeModeFile.delete()
                }
            }
        }
        c.addView(row(0, 1, "Modo seguro del men\u00fa", "Usa el men\u00fa Android en vez del de Unity", Ic.SHIELD, trailing = sw) {
            sw.performClick()
        })

        c.addView(header("Avanzado"))
        c.addView(row(0, 2, "Limpiar cach\u00e9 de mods", "Vuelve a extraer las librer\u00edas", Ic.REFRESH) {
            if (hasStorage()) {
                repo.clearCache()
                Toast.makeText(this, "Cach\u00e9 limpiada", Toast.LENGTH_SHORT).show()
            } else requestStorage()
        })
        val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }
        c.addView(row(1, 2, "Acerca de", "CrewLoader $version", Ic.INFO))

        setScreen(page("Ajustes", c))
    }
}
