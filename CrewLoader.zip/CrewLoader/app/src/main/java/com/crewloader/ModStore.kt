package com.crewloader

import android.content.Context
import android.net.Uri
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile

object ModStore {
    val root = File(Environment.getExternalStorageDirectory(), "CrewLoader")
    val modsDir = File(root, "mods")
    val config = File(root, "config.json")

    data class Mod(
        val file: File,
        val id: String,
        val name: String,
        val version: String,
        val author: String,
        val hasLibForDevice: Boolean
    )

    fun ensureDirs() {
        modsDir.mkdirs()
    }

    private fun readMeta(zf: ZipFile): JSONObject? {
        val e = zf.getEntry("mod.json") ?: return null
        return try {
            JSONObject(zf.getInputStream(e).bufferedReader().readText())
        } catch (_: Exception) {
            null
        }
    }

    private fun hasLib(zf: ZipFile, abi: String): Boolean =
        zf.entries().asSequence().any { it.name.startsWith("lib/$abi/") && it.name.endsWith(".so") }

    fun list(abi: String): List<Mod> {
        val files = modsDir.listFiles { f -> f.isFile && f.name.endsWith(".crewag") } ?: return emptyList()
        return files.sortedBy { it.name }.mapNotNull { f ->
            try {
                ZipFile(f).use { zf ->
                    val j = readMeta(zf) ?: return@use null
                    val id = j.optString("id")
                    if (id.isEmpty()) return@use null
                    Mod(
                        f, id,
                        j.optString("name", id),
                        j.optString("version", "?"),
                        j.optString("author", "?"),
                        hasLib(zf, abi)
                    )
                }
            } catch (_: Exception) {
                null
            }
        }
    }

    fun enabled(): MutableSet<String> {
        val out = mutableSetOf<String>()
        try {
            if (config.exists()) {
                val arr = JSONObject(config.readText()).optJSONArray("enabled") ?: JSONArray()
                for (i in 0 until arr.length()) out.add(arr.getString(i))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun setEnabled(id: String, on: Boolean) {
        val set = enabled()
        if (on) set.add(id) else set.remove(id)
        root.mkdirs()
        config.writeText(JSONObject().put("enabled", JSONArray(set.toList())).toString())
    }

    /** Devuelve null si todo salio bien, o el mensaje de error. */
    fun import(ctx: Context, uri: Uri): String? {
        ensureDirs()
        val tmp = File(ctx.cacheDir, "import.tmp")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                ?: return "No se pudo abrir el archivo"
            val id = ZipFile(tmp).use { zf ->
                val j = readMeta(zf) ?: return "El archivo no tiene un mod.json valido"
                j.optString("id").ifEmpty { return "mod.json no tiene id" }
            }
            val safe = id.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val dest = File(modsDir, "$safe.crewag")
            tmp.copyTo(dest, overwrite = true)
            return null
        } catch (e: Exception) {
            return "Archivo invalido: ${e.message}"
        } finally {
            tmp.delete()
        }
    }
}
