package com.crewloader.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Paleta oscura estilo Material 3 (negro puro + tarjetas gris oscuro + azul claro). */
object Pal {
    val BG = 0xFF000000.toInt()
    val CARD = 0xFF1F1F1F.toInt()
    val TEXT = 0xFFE6E6E6.toInt()
    val TEXT2 = 0xFFB4B4B4.toInt()
    val PRIMARY = 0xFFB6C4FF.toInt()
    val ON_PRIMARY = 0xFF0A2A7A.toInt()
    val OUTLINE = 0xFF8E8E8E.toInt()
    val ERROR = 0xFFFFB4AB.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
fun uniform(r: Float) = FloatArray(8) { r }
fun mediumFont(): Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

fun Context.label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = mediumFont()
    }

/** Fondo redondeado con ripple. strokeColor != null dibuja borde de 1dp (boton "outlined"). */
fun Context.rippleBg(color: Int, radii: FloatArray, strokeColor: Int? = null): Drawable {
    val content = GradientDrawable().apply {
        setColor(color)
        cornerRadii = radii
        if (strokeColor != null) setStroke(dp(1), strokeColor)
    }
    val mask = GradientDrawable().apply {
        setColor(Color.WHITE)
        cornerRadii = radii
    }
    return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, mask)
}

/** Tarjetas agrupadas: la primera redondea arriba, la ultima abajo, las del medio casi rectas. */
fun Context.groupBg(i: Int, n: Int): Drawable {
    val big = dpf(26f)
    val small = dpf(5f)
    val top = if (i == 0) big else small
    val bot = if (i == n - 1) big else small
    return rippleBg(Pal.CARD, floatArrayOf(top, top, top, top, bot, bot, bot, bot))
}

enum class Ic { PLAY, GEAR, BACK, PLUS, TRASH, FOLDER, SHIELD, REFRESH, INFO }

/** Iconos de trazo dibujados a mano sobre una cuadricula de 24x24. */
class IconView(ctx: Context, private val icon: Ic, private val color: Int = Pal.TEXT) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(c: Canvas) {
        val w = width - paddingLeft - paddingRight
        val h = height - paddingTop - paddingBottom
        val s = min(w, h) / 24f
        c.save()
        c.translate(paddingLeft + (w - 24 * s) / 2f, paddingTop + (h - 24 * s) / 2f)
        c.scale(s, s)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        when (icon) {
            Ic.PLAY -> c.drawPath(Path().apply {
                moveTo(7f, 4.5f); lineTo(19f, 12f); lineTo(7f, 19.5f); close()
            }, p)
            Ic.BACK -> {
                c.drawLine(19f, 12f, 5f, 12f, p)
                c.drawLine(12f, 5f, 5f, 12f, p)
                c.drawLine(12f, 19f, 5f, 12f, p)
            }
            Ic.PLUS -> {
                c.drawLine(12f, 5f, 12f, 19f, p)
                c.drawLine(5f, 12f, 19f, 12f, p)
            }
            Ic.TRASH -> {
                c.drawLine(4f, 7f, 20f, 7f, p)
                c.drawPath(Path().apply {
                    moveTo(9f, 7f); lineTo(9f, 4f); lineTo(15f, 4f); lineTo(15f, 7f)
                }, p)
                c.drawPath(Path().apply {
                    moveTo(6f, 7f); lineTo(7f, 20f); lineTo(17f, 20f); lineTo(18f, 7f)
                }, p)
                c.drawLine(10f, 11f, 10f, 16f, p)
                c.drawLine(14f, 11f, 14f, 16f, p)
            }
            Ic.FOLDER -> c.drawPath(Path().apply {
                moveTo(3f, 6f); lineTo(9f, 6f); lineTo(11f, 9f); lineTo(21f, 9f)
                lineTo(21f, 19f); lineTo(3f, 19f); close()
            }, p)
            Ic.SHIELD -> c.drawPath(Path().apply {
                moveTo(12f, 3f); lineTo(19f, 6f); lineTo(19f, 12f)
                cubicTo(19f, 16.5f, 16f, 19.5f, 12f, 21f)
                cubicTo(8f, 19.5f, 5f, 16.5f, 5f, 12f)
                lineTo(5f, 6f); close()
            }, p)
            Ic.REFRESH -> {
                c.drawArc(RectF(4f, 4f, 20f, 20f), 30f, 300f, false, p)
                c.drawLine(19f, 16f, 19f, 11f, p)
                c.drawLine(19f, 16f, 14f, 16f, p)
            }
            Ic.INFO -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawLine(12f, 11f, 12f, 16f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(12f, 8f, 1.2f, p)
            }
            Ic.GEAR -> {
                p.strokeWidth = 3f
                for (k in 0 until 8) {
                    val a = Math.toRadians(45.0 * k)
                    c.drawLine(
                        12f + (6.5 * cos(a)).toFloat(), 12f + (6.5 * sin(a)).toFloat(),
                        12f + (9.6 * cos(a)).toFloat(), 12f + (9.6 * sin(a)).toFloat(), p
                    )
                }
                p.strokeWidth = 2f
                c.drawCircle(12f, 12f, 6.5f, p)
                c.drawCircle(12f, 12f, 2.6f, p)
            }
        }
        c.restore()
    }
}

/** Switch estilo Material 3 (pista azul clara + pulgar azul oscuro cuando esta activo). */
class M3Switch(ctx: Context) : View(ctx) {
    var checked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null
    private var t = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val argb = ArgbEvaluator()

    init {
        setOnClickListener { toggle() }
    }

    /** Fija el estado sin animar ni avisar. */
    fun set(v: Boolean) {
        checked = v
        t = if (v) 1f else 0f
        invalidate()
    }

    private fun toggle() {
        checked = !checked
        ValueAnimator.ofFloat(t, if (checked) 1f else 0f).apply {
            duration = 160
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
        }.start()
        onChange?.invoke(checked)
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        setMeasuredDimension(context.dp(52), context.dp(32))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        paint.style = Paint.Style.FILL
        paint.color = argb.evaluate(t, Pal.CARD, Pal.PRIMARY) as Int
        c.drawRoundRect(0f, 0f, w, h, r, r, paint)
        val sw = context.dpf(2f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = sw
        paint.color = Pal.OUTLINE
        paint.alpha = ((1f - t) * 255).toInt()
        c.drawRoundRect(sw / 2, sw / 2, w - sw / 2, h - sw / 2, r, r, paint)
        paint.alpha = 255
        paint.style = Paint.Style.FILL
        val thumbR = context.dpf(8f) + (context.dpf(12f) - context.dpf(8f)) * t
        val cx = r + (w - 2 * r) * t
        paint.color = argb.evaluate(t, Pal.OUTLINE, Pal.ON_PRIMARY) as Int
        c.drawCircle(cx, h / 2f, thumbR, paint)
    }
}

/** Logo propio: casco hexagonal con borde en degradado y visor. */
class LogoView(ctx: Context) : View(ctx) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - context.dpf(5f)
        stroke.strokeWidth = context.dpf(5f)
        stroke.pathEffect = CornerPathEffect(r * 0.22f)
        stroke.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(0xFFFFFFFF.toInt(), 0xFFC8B6F6.toInt(), 0xFF7B68E0.toInt()),
            null, Shader.TileMode.CLAMP
        )
        val hex = Path()
        for (k in 0 until 6) {
            val a = Math.toRadians((-90 + 60 * k).toDouble())
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (k == 0) hex.moveTo(x, y) else hex.lineTo(x, y)
        }
        hex.close()
        c.drawPath(hex, stroke)

        val vw = r * 1.15f
        val vh = r * 0.62f
        val rect = RectF(
            cx - vw / 2 + r * 0.12f, cy - vh / 2 - r * 0.06f,
            cx + vw / 2 + r * 0.12f, cy + vh / 2 - r * 0.06f
        )
        fill.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            0xFFE9F0FF.toInt(), 0xFFB6C4FF.toInt(), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, vh / 2, vh / 2, fill)
    }
}
