package com.crewloader;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.view.InputEvent;
import android.view.View;

import java.lang.reflect.Method;

/**
 * Esta clase se carga con el ClassLoader "mezclado" (nuestro dex + dex del juego).
 * Sin dependencias de Kotlin a proposito.
 */
public final class Bootstrap {
    private Bootstrap() {}

    static native void nativeInit(String modsDir, String configPath, String cacheDir);

    public static Object createPlayer(Activity act, String modsDir, String configPath, String cacheDir) throws Exception {
        // 1) Cargar el loader ANTES de que Unity cargue libunity/libil2cpp.
        System.loadLibrary("crewloader");
        nativeInit(modsDir, configPath, cacheDir);

        // 2) Arrancar UnityPlayer del juego original.
        ClassLoader cl = Bootstrap.class.getClassLoader();
        Class<?> up = Class.forName("com.unity3d.player.UnityPlayer", true, cl);
        try {
            return up.getConstructor(Context.class).newInstance(act);
        } catch (NoSuchMethodException e) {
            Class<?> ev = Class.forName("com.unity3d.player.IUnityPlayerLifecycleEvents", true, cl);
            return up.getConstructor(Context.class, ev).newInstance(act, null);
        }
    }

    public static View viewOf(Object player) throws Exception {
        if (player instanceof View) return (View) player;
        Method m = player.getClass().getMethod("getFrameLayout");
        return (View) m.invoke(player);
    }

    public static void lifecycle(Object player, String name) {
        try { player.getClass().getMethod(name).invoke(player); } catch (Throwable ignored) {}
    }

    public static void focus(Object player, boolean hasFocus) {
        try { player.getClass().getMethod("windowFocusChanged", boolean.class).invoke(player, hasFocus); }
        catch (Throwable ignored) {}
    }

    public static void config(Object player, Configuration c) {
        try { player.getClass().getMethod("configurationChanged", Configuration.class).invoke(player, c); }
        catch (Throwable ignored) {}
    }

    public static boolean inject(Object player, InputEvent e) {
        try {
            Object r = player.getClass().getMethod("injectEvent", InputEvent.class).invoke(player, e);
            return r instanceof Boolean && (Boolean) r;
        } catch (Throwable t) { return false; }
    }
}
