# CrewLoader

Mod loader estilo Geode para Among Us Android. **Sin root. Sin tocar el APK.**

## Como funciona (arquitectura sin root)
Android no permite inyectar codigo en otra app. La tecnica usada (la misma idea del Geode Launcher):
CrewLoader **hospeda el juego instalado dentro de su propio proceso**:

1. `GameActivity` lee el APK de Among Us (y sus splits) de `com.innersloth.spacemafia`, tal cual esta en Play Store.
2. Crea un `PathClassLoader` con el dex de CrewLoader + el dex del juego, y rutas nativas del juego + `libcrewloader.so`.
3. `Bootstrap.createPlayer()` carga **`libcrewloader.so` primero** y despues crea el `UnityPlayer` del juego.
4. `libcrewloader.so` espera `libil2cpp.so` (dlopen RTLD_NOLOAD), espera `il2cpp_domain_get()`, lee
   `/storage/emulated/0/CrewLoader/config.json`, extrae y carga cada mod activo y llama `crew_mod_init(api)`.
5. El menu in-game se crea con GameObject/Canvas/Button reales de Unity (il2cpp_runtime_invoke), en el main thread
   mediante un delegate nativo registrado en `Application.onBeforeRender`.

El juego debe estar instalado desde Play Store. No se modifica, re-firma ni copia.
`targetSdk=28` es intencional (permite dlopen de .so extraidos y acceso a /storage/emulated/0).

## Compilar
Sube la carpeta a un repo de GitHub: el workflow `.github/workflows/build.yml` compila y publica
`CrewLoader.apk` en Releases. (Tambien abre en Android Studio.)

## Mods (.crewag)
ZIP con `mod.json`, `lib/arm64-v8a/libX.so`, `lib/armeabi-v7a/libX.so`; exporta
`extern "C" void crew_mod_init(const CrewApi*)`. Ejemplo en `examples/hello_mod`.
Config de mods activos: `/storage/emulated/0/CrewLoader/config.json` -> `{"enabled":["mi.mod"]}`.

## Logs
`adb logcat -s CrewLoader` (cada mod: cargado OK o el motivo del fallo).

## Limitaciones conocidas (honestas)
- Codigo NO probado en un dispositivo: el primer build/arranque puede requerir ajustes. Pasa los logs.
- Among Us puede tener Application class propia, split APKs o Play Integrity que afecten el arranque.
- El menu depende de que `UnityEngine.UI` (o TextMeshPro) no este "stripped" en el IL2CPP del juego;
  si falta algo, el log `CrewLoader` dice exactamente que clase.
- El menu muestra hasta 7 mods; el resto se administra desde la app.
- Usalo solo en modo offline/privado: mods en partidas publicas pueden causar baneos.
