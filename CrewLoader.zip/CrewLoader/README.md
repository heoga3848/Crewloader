# CrewLoader

Mod loader para **Among Us (Android, Unity IL2CPP, `com.innersloth.spacemafia`)**.
Sin root. No modifica, descomprime ni re-firma el APK del juego. Codigo propio (no copia nada de Geode).

## Compilar
- GitHub Actions: sube el repo a GitHub, haz push a `main` (o crea un tag `v0.1.0`). El APK aparece en **Releases**.
- Local: JDK 17 + Android SDK/NDK + `gradle :app:assembleRelease`.

## Usar
1. Instala el APK, abre CrewLoader, concede "Acceso a todos los archivos".
2. Importa `.crewag` (se guardan en `/storage/emulated/0/CrewLoader/mods/`).
3. Activa/desactiva con el switch y pulsa **JUGAR** (Among Us debe estar instalado desde Play Store).
4. En el juego: boton **CREW** -> panel de mods.

## Formato .crewag (ZIP)
```
mod.json                      {"id":"mi.mod","name":"Mi Mod","version":"1.0.0","author":"yo"}
lib/arm64-v8a/libXXX.so
lib/armeabi-v7a/libXXX.so
```
Cada mod exporta `extern "C" void crew_mod_init(const CrewApi* api)` (ver `sdk/crew_api.h`, ejemplo en `sdk/example_mod.cpp`).

## Depurar
`adb logcat -s CrewLoader` — veras: libil2cpp detectada -> domain listo -> mods cargados -> menu creado.
Si el menu Unity falla, aparece un menu Android de respaldo. Para forzarlo (modo seguro, por si el juego se cierra):
crea el archivo vacio `/storage/emulated/0/CrewLoader/disable_ui`.

## Limites conocidos
- El juego corre dentro del proceso de CrewLoader (no del paquete original): Google Play Games / compras / login pueden no funcionar y los datos guardados son aparte.
- Depende de la version de Unity de Among Us; el boton/panel usa metodos de UnityEngine.UI que pueden estar recortados.
- Desactivar un mod ya cargado requiere reiniciar el juego.
