# CrewLoader (Android)

Launcher + cargador + gestor de mods `.crewag` para Among Us.

## Compilar
1. Android Studio (Koala o superior) → Open → esta carpeta.
2. Instala NDK y CMake cuando lo pida (SDK Manager).
3. Build → Build APK(s) → instala `app-debug.apk` en el móvil.

## Cómo funciona
- **Gestor**: importa archivos `.crewag` (ZIP con `mod.json` + `lib/<abi>/*.so`), valida, activa y desactiva.
- **Cargador**: al pulsar «Aplicar mods e instalar», la app copia los APK instalados de Among Us,
  coloca un proxy (`libmain.so`) que carga el `libmain.so` original (`libmain_orig.so`) y después
  los mods (`libcrewmodN.so`), vuelve a firmar con una clave propia generada en tu móvil e instala.
- **Primera vez**: hay que desinstalar el Among Us original (la firma cambia). Las siguientes
  veces se actualiza encima sin perder datos.

## Crear un mod
Mira `sdk/`: `crew_mod_api.h`, `example_mod/` y `pack_crewag.py`.
Compila con el NDK (`aarch64-linux-android28-clang++ -shared -fPIC mod.cpp -o libhello.so -llog`)
y empaqueta con `pack_crewag.py`. Un `.so` por ABI.

## Límites conocidos
- No se ha compilado ni probado en un dispositivo.
- Asume que el juego es Unity con `libmain.so` (como Among Us hasta ahora). Si una actualización
  cambia eso, el parcheo falla con un mensaje claro.
- Cada cambio de mods requiere volver a pulsar «Aplicar» (re-parchea e instala encima).
- Mantén la app abierta mientras parchea (el APK pesa >100 MB).

## Compilar en GitHub
Sube esta carpeta a un repositorio. En la pestaña **Actions** se ejecuta «Build APK»
(o pulsa «Run workflow»). Al terminar, descarga `CrewLoader-apk` desde **Artifacts**.
