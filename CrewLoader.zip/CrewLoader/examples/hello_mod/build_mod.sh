#!/bin/sh
# Uso: NDK=/ruta/al/ndk ./build_mod.sh   -> genera hello.crewag
set -e
T=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
mkdir -p lib/arm64-v8a lib/armeabi-v7a
$T/aarch64-linux-android26-clang++ -shared -fPIC -o lib/arm64-v8a/libhello.so hello.cpp -llog
$T/armv7a-linux-androideabi26-clang++ -shared -fPIC -o lib/armeabi-v7a/libhello.so hello.cpp -llog
rm -f hello.crewag
zip -r hello.crewag mod.json lib
echo "Listo: hello.crewag"
