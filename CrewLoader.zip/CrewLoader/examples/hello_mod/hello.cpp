#include <android/log.h>
#include <jni.h>
#include <stdint.h>

typedef struct CrewApi {
    uint32_t version;
    JavaVM* vm;
    void (*log)(int priority, const char* tag, const char* message);
} CrewApi;

extern "C" __attribute__((visibility("default"))) void crew_mod_init(const CrewApi* api) {
    api->log(ANDROID_LOG_INFO, "HelloMod", "Hola desde un mod .crewag!");
}
