// Mod de ejemplo: compilalo como libhello.so y metelo en un .crewag
#include "crew_api.h"
#include <android/log.h>

extern "C" __attribute__((visibility("default")))
void crew_mod_init(const CrewApi* api) {
    api->log(ANDROID_LOG_INFO, "HelloMod", "Hola desde un mod .crewag!");
}
