#!/usr/bin/env python3
"""Empaqueta un mod .crewag.
Uso: python pack_crewag.py salida.crewag mod.json arm64-v8a=libmod.so [armeabi-v7a=libmod.so]
"""
import sys, json, zipfile

out, manifest, *libs = sys.argv[1:]
m = json.load(open(manifest, encoding="utf-8"))
assert all(k in m for k in ("id", "name", "version")), "mod.json necesita id, name, version"
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(manifest, "mod.json")
    for spec in libs:
        abi, path = spec.split("=", 1)
        z.write(path, f"lib/{abi}/lib{m['id'].replace('.', '_')}.so")
print("Creado", out)
