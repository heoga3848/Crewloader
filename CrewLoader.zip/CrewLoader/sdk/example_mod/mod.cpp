#include <android/log.h>
#include "../crew_mod_api.h"

CREW_MOD_ENTRY {
    api->log(ANDROID_LOG_INFO, "HelloCrew", "Hola desde un mod .crewag");
}
